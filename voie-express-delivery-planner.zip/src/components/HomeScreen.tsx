// ═══════════════════════════════════════════════════════════════
// TELA 1 — HOME / PLANEJADOR DE ROTA
// Entrada de endereços, configuração de prioridade e veículo
// ═══════════════════════════════════════════════════════════════

import { useState, useCallback } from 'react';
import {
  MapPin, Upload, ChevronDown, ChevronUp, Truck,
  AlertTriangle, Zap, Route, Leaf, Shield, BarChart3
} from 'lucide-react';
import type { Priority, VehicleType } from '../types';
import type { AppStore } from '../store/appStore';
import { MOCK_ADDRESSES } from '../constants';
import { calculateOptimalRoute } from '../services/routeEngine';

interface HomeScreenProps {
  store: AppStore;
}

const PRIORITIES: { id: Priority; label: string; icon: React.ReactNode; desc: string }[] = [
  { id: 'fastest', label: 'Rápido', icon: <Zap size={14} />, desc: 'Menor tempo' },
  { id: 'shortest', label: 'Curto', icon: <Route size={14} />, desc: 'Menor distância' },
  { id: 'economic', label: 'Econômico', icon: <Leaf size={14} />, desc: 'Menor consumo' },
  { id: 'safest', label: 'Seguro', icon: <Shield size={14} />, desc: 'Menor risco' },
  { id: 'balanced', label: 'Equilibrado', icon: <BarChart3 size={14} />, desc: 'Balanceado' },
];

const VEHICLES: { id: VehicleType; label: string; emoji: string }[] = [
  { id: 'car', label: 'Carro', emoji: '🚗' },
  { id: 'motorcycle', label: 'Moto', emoji: '🏍️' },
  { id: 'truck', label: 'Caminhão', emoji: '🚛' },
  { id: 'van', label: 'Van', emoji: '🚐' },
  { id: 'boat', label: 'Barco', emoji: '⛵' },
];

export function HomeScreen({ store }: HomeScreenProps) {
  const { settings, navigate, setCurrentRoute, setLoadingProgress, showToast } = store;
  const [addresses, setAddresses] = useState(MOCK_ADDRESSES.map(m => m.address).join('\n'));
  const [priority, setPriority] = useState<Priority>(settings.defaultPriority);
  const [vehicle, setVehicle] = useState<VehicleType>(settings.defaultVehicle);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [avoidDirt, setAvoidDirt] = useState(settings.avoidDirt);
  const [avoidFlood, setAvoidFlood] = useState(settings.avoidFlood);
  const [avoidSlopes, setAvoidSlopes] = useState(settings.avoidSlopes);
  const [avoidNoSignal, setAvoidNoSignal] = useState(settings.avoidNoSignal);
  const [preferAsphalt, setPreferAsphalt] = useState(settings.preferAsphalt);
  const [isCalculating, setIsCalculating] = useState(false);

  // Importar CSV (mock)
  const handleImportCSV = useCallback(() => {
    const mockCSV = MOCK_ADDRESSES.map(m => m.address).join('\n');
    setAddresses(mockCSV);
    showToast('6 endereços importados do CSV de exemplo!', 'success');
  }, [showToast]);

  // Calcular rota
  const handleCalculate = useCallback(async () => {
    const lines = addresses.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length < 2) {
      showToast('Insira pelo menos 2 endereços para calcular a rota.', 'error');
      return;
    }
    if (lines.length > 15) {
      showToast('Máximo de 15 endereços por rota no MVP.', 'warning');
      return;
    }

    setIsCalculating(true);
    navigate('loading');

    try {
      const route = await calculateOptimalRoute(
        lines, priority, vehicle,
        { avoidDirt, avoidFlood, avoidSlopes, avoidNoSignal, preferAsphalt },
        (step, total, message) => setLoadingProgress({ step, total, message })
      );
      setCurrentRoute(route);
      navigate('route');
      showToast(`Rota calculada! Score: ${route.score}/100`, route.score >= 70 ? 'success' : 'warning');
    } catch (err) {
      console.error(err);
      showToast('Erro ao calcular rota. Verifique os endereços.', 'error');
      navigate('home');
    } finally {
      setIsCalculating(false);
    }
  }, [addresses, priority, vehicle, avoidDirt, avoidFlood, avoidSlopes, avoidNoSignal, preferAsphalt,
      navigate, setCurrentRoute, setLoadingProgress, showToast]);

  return (
    <div className="min-h-screen bg-[#0F172A] pt-14 pb-16 md:pb-0">
      <div className="max-w-4xl mx-auto px-4 py-8">

        {/* Hero */}
        <div className="text-center mb-10 animate-fade-in">
          <div className="inline-flex flex-col items-center gap-3 mb-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#0B3D2E] to-[#00D4AA]/30 flex items-center justify-center border border-[#00D4AA]/30 shadow-[0_0_40px_rgba(0,212,170,0.2)]">
                <span className="text-4xl">📦</span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#00D4AA] flex items-center justify-center shadow-[0_0_10px_#00D4AA] animate-pulse">
                <MapPin size={12} className="text-white" />
              </div>
            </div>
            <div>
              <h2 className="font-display text-3xl md:text-4xl text-white font-bold">
                Planeje sua Rota
              </h2>
              <p className="text-slate-400 text-sm mt-1">
                IA otimiza sua sequência considerando clima, relevo e trânsito em tempo real
              </p>
            </div>
          </div>

          {/* Badges de feature */}
          <div className="flex flex-wrap justify-center gap-2 mb-6">
            {['🌦️ Clima em Tempo Real', '⛰️ Relevo e Elevação', '🚦 Incidentes de Trânsito', '🌊 Sazonalidade'].map(f => (
              <span key={f} className="px-3 py-1 rounded-full bg-[#1E293B] border border-white/10 text-xs text-slate-300">
                {f}
              </span>
            ))}
          </div>
        </div>

        {/* Card Principal */}
        <div className="bg-[#1E293B] rounded-2xl border border-white/10 shadow-2xl p-6 space-y-6 animate-slide-up">

          {/* Área de Endereços */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-widest">
                Endereços de Entrega
              </label>
              <button
                onClick={handleImportCSV}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#D4A017]/10 border border-[#D4A017]/30 text-[#D4A017] text-xs font-medium hover:bg-[#D4A017]/20 transition-all"
              >
                <Upload size={12} />
                Importar CSV
              </button>
            </div>
            <textarea
              value={addresses}
              onChange={e => setAddresses(e.target.value)}
              placeholder={"Cole os endereços aqui, um por linha:\nEx: Av. Eduardo Ribeiro, 520 - Centro, Manaus\nRua Flores, 100 - Adrianópolis, Manaus"}
              rows={8}
              className="w-full bg-[#0F172A] border border-white/10 rounded-xl px-4 py-3 text-slate-200 text-sm placeholder:text-slate-600 focus:outline-none focus:border-[#00D4AA]/50 focus:ring-1 focus:ring-[#00D4AA]/30 resize-none transition-all font-mono leading-relaxed"
            />
            <p className="text-xs text-slate-500 mt-1.5">
              {addresses.split('\n').filter(Boolean).length} endereço(s) inserido(s) · máx. 15
            </p>
          </div>

          {/* Prioridade */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-widest block mb-3">
              Prioridade de Otimização
            </label>
            <div className="grid grid-cols-5 gap-2">
              {PRIORITIES.map(p => (
                <button
                  key={p.id}
                  onClick={() => setPriority(p.id)}
                  className={`
                    flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border text-center
                    transition-all duration-200
                    ${priority === p.id
                      ? 'bg-[#00D4AA]/15 border-[#00D4AA]/60 text-[#00D4AA] shadow-[0_0_15px_rgba(0,212,170,0.15)]'
                      : 'bg-[#0F172A]/60 border-white/10 text-slate-400 hover:border-white/20 hover:text-white'
                    }
                  `}
                >
                  <span>{p.icon}</span>
                  <span className="text-xs font-semibold">{p.label}</span>
                  <span className="text-[10px] opacity-70">{p.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Tipo de Veículo */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-widest block mb-3">
              Tipo de Veículo
            </label>
            <div className="flex gap-2 flex-wrap">
              {VEHICLES.map(v => (
                <button
                  key={v.id}
                  onClick={() => setVehicle(v.id)}
                  className={`
                    flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium
                    transition-all duration-200
                    ${vehicle === v.id
                      ? 'bg-[#0B3D2E] border-[#00D4AA]/60 text-[#00D4AA]'
                      : 'bg-[#0F172A]/60 border-white/10 text-slate-400 hover:border-white/20 hover:text-white'
                    }
                  `}
                >
                  <span className="text-lg">{v.emoji}</span>
                  {v.label}
                </button>
              ))}
            </div>
          </div>

          {/* Opções Avançadas */}
          <div>
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition-colors"
            >
              {showAdvanced ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              <span className="font-medium">Opções Avançadas</span>
              {(avoidDirt || avoidFlood || avoidSlopes || avoidNoSignal) && (
                <span className="ml-1 px-2 py-0.5 rounded-full bg-[#F4A261]/20 text-[#F4A261] text-xs">
                  {[avoidDirt, avoidFlood, avoidSlopes, avoidNoSignal].filter(Boolean).length} ativas
                </span>
              )}
            </button>

            {showAdvanced && (
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 animate-fade-in">
                {[
                  { key: 'avoidDirt', label: 'Evitar ruas de terra', emoji: '🌱', state: avoidDirt, setter: setAvoidDirt },
                  { key: 'avoidFlood', label: 'Evitar alagamentos', emoji: '🌊', state: avoidFlood, setter: setAvoidFlood },
                  { key: 'avoidSlopes', label: 'Evitar ladeiras íngremes', emoji: '⛰️', state: avoidSlopes, setter: setAvoidSlopes },
                  { key: 'avoidNoSignal', label: 'Evitar áreas sem sinal', emoji: '📵', state: avoidNoSignal, setter: setAvoidNoSignal },
                  { key: 'preferAsphalt', label: 'Priorizar asfalto', emoji: '🛣️', state: preferAsphalt, setter: setPreferAsphalt },
                ].map(opt => (
                  <label
                    key={opt.key}
                    className={`
                      flex items-center gap-3 p-3 rounded-xl border cursor-pointer
                      transition-all duration-200
                      ${opt.state
                        ? 'bg-[#0B3D2E]/50 border-[#00D4AA]/30'
                        : 'bg-[#0F172A]/60 border-white/10 hover:border-white/20'
                      }
                    `}
                  >
                    <input
                      type="checkbox"
                      checked={opt.state}
                      onChange={e => opt.setter(e.target.checked)}
                      className="sr-only"
                    />
                    <div className={`w-5 h-5 rounded flex items-center justify-center border-2 transition-all ${opt.state ? 'bg-[#00D4AA] border-[#00D4AA]' : 'border-white/30'}`}>
                      {opt.state && <span className="text-white text-xs font-bold">✓</span>}
                    </div>
                    <span className="text-sm">{opt.emoji}</span>
                    <span className="text-sm text-slate-300">{opt.label}</span>
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* Aviso de Risco */}
          {avoidFlood && (
            <div className="flex items-start gap-3 p-3 rounded-xl bg-[#F4A261]/10 border border-[#F4A261]/30">
              <AlertTriangle size={16} className="text-[#F4A261] mt-0.5 flex-shrink-0" />
              <p className="text-xs text-[#F4A261]">
                Modo "Evitar alagamentos" ativo — trechos com histórico de cheia receberão penalidade de risco adicional.
              </p>
            </div>
          )}

          {/* Botão Principal */}
          <button
            onClick={handleCalculate}
            disabled={isCalculating}
            className={`
              w-full py-4 rounded-xl font-display font-bold text-lg
              bg-gradient-to-r from-[#00D4AA] to-[#0B3D2E]
              text-white shadow-[0_0_30px_rgba(0,212,170,0.3)]
              hover:shadow-[0_0_40px_rgba(0,212,170,0.5)] hover:-translate-y-0.5
              active:translate-y-0 transition-all duration-200
              disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-none disabled:hover:translate-y-0
              flex items-center justify-center gap-3
            `}
          >
            <Truck size={20} />
            {isCalculating ? 'Calculando...' : 'Calcular Melhor Rota'}
          </button>

          {/* Rodapé informativo */}
          <p className="text-center text-xs text-slate-600">
            Powered by OpenRouteService · OpenWeatherMap · TomTom Traffic · OpenTopoData · Visual Crossing · INMET
          </p>
        </div>
      </div>

      {/* Seção de features (abaixo do card) */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <p className="text-center text-xs font-semibold text-slate-500 uppercase tracking-widest mb-6">
          Como o motor de decisão funciona
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            {
              emoji: '🧮',
              title: 'Função de Custo',
              desc: 'w₁·Distância + w₂·Tempo + w₃·Consumo + w₄·Risco',
              color: '#00D4AA',
            },
            {
              emoji: '🌦️',
              title: 'Penalidades Climáticas',
              desc: 'Tempestade +30% · Chuva forte +15% · Alagamento histórico +10%',
              color: '#3B82F6',
            },
            {
              emoji: '⛰️',
              title: 'Análise de Relevo',
              desc: 'SRTM 30m · Ladeiras > 15% bloqueadas para caminhão',
              color: '#D4A017',
            },
            {
              emoji: '🤖',
              title: 'VRP Simplificado',
              desc: 'Algoritmo guloso com janelas de tempo e múltiplos critérios',
              color: '#F4A261',
            },
          ].map(f => (
            <div
              key={f.title}
              className="bg-[#1E293B] rounded-xl border border-white/10 p-4 hover:border-white/20 hover:-translate-y-1 transition-all duration-200"
            >
              <div className="text-2xl mb-3">{f.emoji}</div>
              <h4 className="text-sm font-semibold text-white mb-1">{f.title}</h4>
              <p className="text-xs text-slate-500 leading-relaxed font-mono">{f.desc}</p>
            </div>
          ))}
        </div>

        {/* Rodapé do app */}
        <div className="text-center mt-8 space-y-1">
          <p className="text-xs text-slate-600">
            Voie Express MVP v1.0 · Offline-First PWA · IndexedDB + Service Worker
          </p>
          <p className="text-xs text-slate-700">
            Dados mock disponíveis para Manaus — AM quando APIs estiverem indisponíveis
          </p>
        </div>
      </div>
    </div>
  );
}
