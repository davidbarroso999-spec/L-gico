// ═══════════════════════════════════════════════════════════════
// TELA 4 — MODO NAVEGAÇÃO
// Mapa em tela cheia, confirmação de entregas, reportes de ocorrências
// ═══════════════════════════════════════════════════════════════

import { useState, useCallback } from 'react';
import {
  CheckCircle, AlertTriangle, Flag, X, Camera,
  WifiOff, RefreshCw, ChevronRight, Navigation,
  ChevronLeft
} from 'lucide-react';
import type { IncidentType } from '../types';
import type { AppStore } from '../store/appStore';
import { MapView } from './MapView';
import { formatDistance, formatDuration } from '../store/appStore';
import { saveOccurrence } from '../services/db';

interface NavigateScreenProps {
  store: AppStore;
}

type OccurrenceModalState = 'closed' | 'open' | 'confirm';

const OCCURRENCE_TYPES: { id: IncidentType; label: string; emoji: string; color: string }[] = [
  { id: 'road_closed', label: 'Via Bloqueada', emoji: '🚫', color: '#E63946' },
  { id: 'flood', label: 'Alagamento', emoji: '🌊', color: '#3B82F6' },
  { id: 'pothole', label: 'Buraco na Via', emoji: '🕳️', color: '#92400E' },
  { id: 'accident', label: 'Acidente', emoji: '💥', color: '#E63946' },
  { id: 'construction', label: 'Obras', emoji: '🚧', color: '#F4A261' },
  { id: 'other', label: 'Outro', emoji: '⚠️', color: '#D4A017' },
];

const FAILURE_REASONS = [
  'Destinatário ausente',
  'Endereço não encontrado',
  'Recusa de recebimento',
  'Acesso bloqueado',
  'Produto danificado',
  'Outro motivo',
];

export function NavigateScreen({ store }: NavigateScreenProps) {
  const { currentRoute, navigate, showToast, isOnline, currentStopIndex, setCurrentStopIndex } = store;
  const [offlineMode, setOfflineMode] = useState(false);
  const [occurrenceModal, setOccurrenceModal] = useState<OccurrenceModalState>('closed');
  const [failureModal, setFailureModal] = useState(false);
  const [selectedOccurrenceType, setSelectedOccurrenceType] = useState<IncidentType | null>(null);
  const [occurrenceNote, setOccurrenceNote] = useState('');
  const [selectedFailure, setSelectedFailure] = useState<string>('');
  const [completedStops, setCompletedStops] = useState<Set<number>>(new Set());
  const [routeAlerts] = useState([
    { id: 1, message: 'Chuva forte em 2km — reduza a velocidade', type: 'warning', visible: true },
    { id: 2, message: 'Congestionamento reportado à frente', type: 'info', visible: true },
  ]);

  if (!currentRoute) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center pt-14">
        <div className="text-center text-slate-400">
          <Navigation size={48} className="mx-auto mb-4 opacity-30" />
          <p>Nenhuma rota ativa. Calcule uma rota primeiro.</p>
          <button onClick={() => navigate('home')} className="mt-4 px-4 py-2 rounded-lg bg-[#00D4AA]/20 text-[#00D4AA] text-sm hover:bg-[#00D4AA]/30 transition-all">
            Calcular Rota
          </button>
        </div>
      </div>
    );
  }

  const route = currentRoute;
  const totalStops = route.stops.length;
  const currentStop = route.stops[currentStopIndex];
  const nextStop = route.stops[currentStopIndex + 1];
  const currentLeg = route.legs[currentStopIndex];
  const progress = (completedStops.size / (totalStops - 1)) * 100;
  const isLastStop = currentStopIndex >= totalStops - 1;

  // Confirmar entrega
  const handleDelivered = useCallback(() => {
    if (isLastStop) {
      setCompletedStops(prev => new Set([...prev, currentStopIndex]));
      showToast('🎉 Todas as entregas concluídas! Sincronizando...', 'success');
      setTimeout(() => navigate('dashboard'), 2000);
      return;
    }
    setCompletedStops(prev => new Set([...prev, currentStopIndex]));
    setCurrentStopIndex(currentStopIndex + 1);
    showToast(`✅ Entrega ${currentStopIndex + 1} confirmada!`, 'success');
  }, [currentStopIndex, isLastStop, navigate, setCurrentStopIndex, showToast]);

  // Registrar falha
  const handleFailure = useCallback(() => {
    if (!selectedFailure) {
      showToast('Selecione o motivo da falha.', 'warning');
      return;
    }
    setCompletedStops(prev => new Set([...prev, currentStopIndex]));
    setFailureModal(false);
    setSelectedFailure('');
    if (!isLastStop) setCurrentStopIndex(currentStopIndex + 1);
    showToast(`⚠️ Falha registrada: ${selectedFailure}`, 'warning');
  }, [currentStopIndex, isLastStop, selectedFailure, setCurrentStopIndex, showToast]);

  // Reportar ocorrência
  const handleReportOccurrence = useCallback(async () => {
    if (!selectedOccurrenceType) {
      showToast('Selecione o tipo de ocorrência.', 'warning');
      return;
    }

    const coord = currentStop.coordinate;
    const occurrence = {
      id: `occ-${Date.now()}`,
      type: selectedOccurrenceType,
      lat: coord?.lat ?? -3.1316,
      lon: coord?.lon ?? -60.0236,
      description: occurrenceNote || (OCCURRENCE_TYPES.find(t => t.id === selectedOccurrenceType)?.label ?? 'Ocorrência'),
      timestamp: new Date().toISOString(),
      synced: false,
      expiresAt: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    };

    await saveOccurrence(occurrence);
    setOccurrenceModal('closed');
    setSelectedOccurrenceType(null);
    setOccurrenceNote('');
    showToast('📍 Ocorrência registrada e será sincronizada quando online.', isOnline ? 'success' : 'warning');
  }, [selectedOccurrenceType, occurrenceNote, currentStop, isOnline, showToast]);

  return (
    <div className={`min-h-screen flex flex-col pt-14 pb-16 md:pb-0 ${offlineMode ? 'grayscale' : ''}`}>
      {/* ── ALERTAS FLUTUANTES ─────────────────────────────────── */}
      <div className="fixed top-16 right-4 z-[500] space-y-2">
        {routeAlerts.map((alert, i) => (
          <div
            key={alert.id}
            className={`
              flex items-center gap-2 px-4 py-2.5 rounded-xl border backdrop-blur-sm shadow-xl
              animate-slide-in max-w-xs
              ${alert.type === 'warning'
                ? 'bg-[#F4A261]/20 border-[#F4A261]/40 text-[#F4A261]'
                : 'bg-[#3B82F6]/20 border-[#3B82F6]/40 text-[#3B82F6]'
              }
            `}
            style={{ animationDelay: `${i * 150}ms` }}
          >
            <AlertTriangle size={14} className="flex-shrink-0" />
            <span className="text-xs font-medium">{alert.message}</span>
          </div>
        ))}
      </div>

      {/* ── MAPA ───────────────────────────────────────────────── */}
      <div className="flex-1 relative">
        <MapView route={route} className="w-full h-full" selectedLeg={currentStopIndex} />

        {/* Card superior — Próxima Parada */}
        <div className="absolute top-4 left-4 right-4 z-[400]">
          <div className="bg-[#1E293B]/95 backdrop-blur-sm rounded-2xl border border-white/10 p-4 shadow-2xl">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-[#00D4AA] flex items-center justify-center">
                  <span className="text-xs font-bold text-[#0B3D2E]">{currentStopIndex + 1}</span>
                </div>
                <span className="text-xs font-semibold text-[#00D4AA] uppercase tracking-widest">
                  {isLastStop ? 'Destino Final' : 'Próxima Parada'}
                </span>
              </div>
              <span className="text-xs text-slate-500">
                {currentStopIndex + 1}/{totalStops}
              </span>
            </div>
            <p className="text-sm font-semibold text-white mb-2 leading-snug">{currentStop.address}</p>

            {currentLeg && (
              <div className="flex items-center gap-4 text-xs text-slate-400">
                <span>📏 {formatDistance(currentLeg.distanceKm)}</span>
                <span>⏱️ {formatDuration(currentLeg.durationMin)}</span>
                {currentLeg.weather && (
                  <span>🌡️ {Math.round(currentLeg.weather.temp)}°C</span>
                )}
              </div>
            )}

            {/* Barra de progresso */}
            <div className="mt-3 h-1.5 bg-[#0F172A] rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #00D4AA, #D4A017)' }}
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-1">{Math.round(progress)}% concluído · {completedStops.size} de {totalStops - 1} entregas</p>
          </div>
        </div>

        {/* Botões de controle offline/sync */}
        <div className="absolute top-4 right-4 z-[400] flex flex-col gap-2" style={{ top: '160px' }}>
          <button
            onClick={() => setOfflineMode(!offlineMode)}
            className={`
              flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border backdrop-blur-sm shadow-lg
              transition-all
              ${offlineMode
                ? 'bg-[#E63946]/20 border-[#E63946]/40 text-[#E63946]'
                : 'bg-[#1E293B]/90 border-white/10 text-slate-300 hover:border-white/30'
              }
            `}
          >
            <WifiOff size={12} />
            {offlineMode ? 'Modo Offline' : 'Offline'}
          </button>
          {isOnline && (
            <button className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#00D4AA]/20 border border-[#00D4AA]/40 text-[#00D4AA] text-xs font-medium backdrop-blur-sm shadow-lg hover:bg-[#00D4AA]/30 transition-all">
              <RefreshCw size={12} />
              Sincronizar
            </button>
          )}
        </div>
      </div>

      {/* ── CONTROLES INFERIORES ────────────────────────────────── */}
      <div className="bg-[#0F172A] border-t border-white/10 p-4 pb-safe">
        {/* Navegação entre paradas */}
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => currentStopIndex > 0 && setCurrentStopIndex(currentStopIndex - 1)}
            disabled={currentStopIndex === 0}
            className="flex items-center gap-1 px-3 py-2 rounded-xl bg-[#1E293B] border border-white/10 text-slate-400 text-sm disabled:opacity-30 hover:border-white/20 hover:text-white transition-all"
          >
            <ChevronLeft size={16} />
            Anterior
          </button>
          <div className="text-center">
            <p className="text-xs text-slate-500">Parada {currentStopIndex + 1} de {totalStops}</p>
            {nextStop && (
              <p className="text-xs text-[#00D4AA] flex items-center gap-1">
                Próxima: {nextStop.address.split(',')[0]}
                <ChevronRight size={10} />
              </p>
            )}
          </div>
          <button
            onClick={() => !isLastStop && setCurrentStopIndex(currentStopIndex + 1)}
            disabled={isLastStop}
            className="flex items-center gap-1 px-3 py-2 rounded-xl bg-[#1E293B] border border-white/10 text-slate-400 text-sm disabled:opacity-30 hover:border-white/20 hover:text-white transition-all"
          >
            Próxima
            <ChevronRight size={16} />
          </button>
        </div>

        {/* Botões principais */}
        <div className="grid grid-cols-3 gap-3">
          {/* Confirmar Entrega */}
          <button
            onClick={handleDelivered}
            disabled={completedStops.has(currentStopIndex)}
            className={`
              flex flex-col items-center justify-center gap-1.5 py-4 rounded-2xl
              font-semibold text-sm transition-all active:scale-95
              ${completedStops.has(currentStopIndex)
                ? 'bg-[#00D4AA]/10 border border-[#00D4AA]/20 text-[#00D4AA]/50 cursor-not-allowed'
                : 'bg-[#00D4AA] text-[#0B3D2E] shadow-[0_0_20px_rgba(0,212,170,0.3)] hover:shadow-[0_0_30px_rgba(0,212,170,0.5)] hover:-translate-y-0.5'
              }
            `}
          >
            <CheckCircle size={24} />
            <span>{completedStops.has(currentStopIndex) ? 'Confirmada' : isLastStop ? 'Concluir Rota' : 'Confirmar'}</span>
          </button>

          {/* Registrar Falha */}
          <button
            onClick={() => setFailureModal(true)}
            disabled={completedStops.has(currentStopIndex)}
            className="flex flex-col items-center justify-center gap-1.5 py-4 rounded-2xl bg-[#F4A261]/20 border border-[#F4A261]/40 text-[#F4A261] font-semibold text-sm hover:bg-[#F4A261]/30 hover:-translate-y-0.5 transition-all active:scale-95 disabled:opacity-30"
          >
            <AlertTriangle size={24} />
            <span>Reg. Falha</span>
          </button>

          {/* Reportar Ocorrência */}
          <button
            onClick={() => setOccurrenceModal('open')}
            className="flex flex-col items-center justify-center gap-1.5 py-4 rounded-2xl bg-[#E63946]/20 border border-[#E63946]/40 text-[#E63946] font-semibold text-sm hover:bg-[#E63946]/30 hover:-translate-y-0.5 transition-all active:scale-95"
          >
            <Flag size={24} />
            <span>Ocorrência</span>
          </button>
        </div>
      </div>

      {/* ── MODAL DE FALHA ─────────────────────────────────────── */}
      {failureModal && (
        <div className="fixed inset-0 z-[300] flex items-end justify-center sm:items-center" onClick={() => setFailureModal(false)}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
          <div
            className="relative w-full max-w-md bg-[#1E293B] rounded-t-3xl sm:rounded-2xl border border-white/10 p-6 animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg text-white font-bold">Registrar Falha de Entrega</h3>
              <button onClick={() => setFailureModal(false)} className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400">
                <X size={18} />
              </button>
            </div>
            <p className="text-sm text-slate-400 mb-4">Selecione o motivo da não-entrega:</p>
            <div className="space-y-2 mb-4">
              {FAILURE_REASONS.map(reason => (
                <button
                  key={reason}
                  onClick={() => setSelectedFailure(reason)}
                  className={`
                    w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all
                    ${selectedFailure === reason
                      ? 'bg-[#F4A261]/20 border-[#F4A261]/50 text-[#F4A261]'
                      : 'bg-[#0F172A] border-white/10 text-slate-300 hover:border-white/20'
                    }
                  `}
                >
                  {reason}
                </button>
              ))}
            </div>
            <button
              onClick={handleFailure}
              className="w-full py-3.5 rounded-xl bg-[#F4A261] text-[#0B3D2E] font-bold text-sm hover:bg-[#F4A261]/90 transition-all"
            >
              Confirmar Falha e Próxima Parada
            </button>
          </div>
        </div>
      )}

      {/* ── MODAL DE OCORRÊNCIA ────────────────────────────────── */}
      {occurrenceModal === 'open' && (
        <div className="fixed inset-0 z-[300] flex items-end justify-center sm:items-center" onClick={() => setOccurrenceModal('closed')}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
          <div
            className="relative w-full max-w-md bg-[#1E293B] rounded-t-3xl sm:rounded-2xl border border-white/10 p-6 animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg text-white font-bold">Reportar Ocorrência</h3>
              <button onClick={() => setOccurrenceModal('closed')} className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400">
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 mb-4">
              {OCCURRENCE_TYPES.map(type => (
                <button
                  key={type.id}
                  onClick={() => setSelectedOccurrenceType(type.id)}
                  className={`
                    flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border text-xs font-medium transition-all
                    ${selectedOccurrenceType === type.id
                      ? `border-opacity-60 text-white`
                      : 'bg-[#0F172A] border-white/10 text-slate-400 hover:border-white/20'
                    }
                  `}
                  style={selectedOccurrenceType === type.id ? {
                    background: `${type.color}20`,
                    borderColor: `${type.color}60`,
                    color: type.color,
                  } : {}}
                >
                  <span className="text-xl">{type.emoji}</span>
                  {type.label}
                </button>
              ))}
            </div>

            <textarea
              value={occurrenceNote}
              onChange={e => setOccurrenceNote(e.target.value)}
              placeholder="Descreva a ocorrência (opcional)..."
              rows={3}
              className="w-full bg-[#0F172A] border border-white/10 rounded-xl px-4 py-3 text-slate-200 text-sm placeholder:text-slate-600 focus:outline-none focus:border-[#E63946]/50 resize-none mb-3"
            />

            <div className="flex items-center gap-2 mb-4">
              <button className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#0F172A] border border-white/10 text-slate-400 text-sm hover:border-white/20 transition-all">
                <Camera size={14} />
                Adicionar Foto
              </button>
              <span className="text-xs text-slate-600">Comprimida automaticamente</span>
            </div>

            <button
              onClick={handleReportOccurrence}
              className="w-full py-3.5 rounded-xl bg-[#E63946] text-white font-bold text-sm hover:bg-[#E63946]/90 transition-all shadow-[0_0_20px_rgba(230,57,70,0.3)]"
            >
              Registrar Ocorrência
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
