// ═══════════════════════════════════════════════════════════════
// TELA 2 — CARREGANDO ROTA
// Spinner animado com mensagens progressivas de status
// ═══════════════════════════════════════════════════════════════

import { useEffect, useState } from 'react';

interface LoadingScreenProps {
  step: number;
  total: number;
  message: string;
}

const STAGES = [
  { emoji: '📍', label: 'Geocodificando endereços', detail: 'Convertendo endereços em coordenadas...' },
  { emoji: '📐', label: 'Calculando distâncias', detail: 'Montando matriz de rotas entre pontos...' },
  { emoji: '🌦️', label: 'Analisando clima', detail: 'Consultando OpenWeatherMap em tempo real...' },
  { emoji: '⛰️', label: 'Verificando relevo', detail: 'Buscando elevação via OpenTopoData SRTM...' },
  { emoji: '🚦', label: 'Incidentes de trânsito', detail: 'Verificando alertas TomTom Traffic...' },
  { emoji: '🌊', label: 'Perfil sazonal', detail: 'Analisando histórico Visual Crossing...' },
  { emoji: '🧠', label: 'Otimizando sequência', detail: 'Algoritmo VRP com função de custo ponderada...' },
  { emoji: '📊', label: 'Calculando riscos', detail: 'Aplicando penalidades por trecho...' },
  { emoji: '🗺️', label: 'Preparando mapa', detail: 'Renderizando visualização da rota...' },
];

export function LoadingScreen({ step, total, message }: LoadingScreenProps) {
  const [dots, setDots] = useState('');
  const progress = total > 0 ? (step / total) * 100 : 0;

  useEffect(() => {
    const interval = setInterval(() => {
      setDots(d => d.length >= 3 ? '' : d + '.');
    }, 400);
    return () => clearInterval(interval);
  }, []);

  const currentStage = STAGES[Math.min(step - 1, STAGES.length - 1)] ?? STAGES[0];

  return (
    <div className="min-h-screen bg-[#0F172A] flex items-center justify-center pt-14">
      <div className="w-full max-w-lg mx-auto px-6 text-center">

        {/* Ícone animado */}
        <div className="relative w-28 h-28 mx-auto mb-8">
          {/* Anéis de radar */}
          <div className="absolute inset-0 rounded-full border-2 border-[#00D4AA]/20 animate-ping-slow" />
          <div className="absolute inset-2 rounded-full border-2 border-[#00D4AA]/30 animate-ping-slower" />
          <div className="absolute inset-4 rounded-full border-2 border-[#00D4AA]/40" />

          {/* Spinner */}
          <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-[#00D4AA] animate-spin" />

          {/* Emoji central */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-4xl">{currentStage.emoji}</span>
          </div>
        </div>

        {/* Mensagem principal */}
        <h2 className="font-display text-2xl text-white font-bold mb-2">
          {message || currentStage.label}{dots}
        </h2>
        <p className="text-slate-400 text-sm mb-8">{currentStage.detail}</p>

        {/* Barra de Progresso */}
        <div className="mb-4">
          <div className="flex justify-between text-xs text-slate-500 mb-2">
            <span>Etapa {step} de {total}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="h-2 bg-[#1E293B] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700 ease-out"
              style={{
                width: `${progress}%`,
                background: 'linear-gradient(90deg, #00D4AA, #D4A017)',
              }}
            />
          </div>
        </div>

        {/* Lista de etapas */}
        <div className="mt-8 space-y-2">
          {STAGES.map((stage, i) => (
            <div
              key={i}
              className={`
                flex items-center gap-3 px-4 py-2.5 rounded-lg
                transition-all duration-300
                ${i < step ? 'bg-[#00D4AA]/10 border border-[#00D4AA]/20' :
                  i === step - 1 ? 'bg-[#1E293B] border border-[#00D4AA]/40' :
                  'opacity-30'}
              `}
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <span className="text-lg w-7 text-center">{stage.emoji}</span>
              <span className="text-sm text-slate-300 flex-1 text-left">{stage.label}</span>
              {i < step && (
                <span className="text-[#00D4AA] text-sm">✓</span>
              )}
              {i === step - 1 && (
                <div className="w-3 h-3 rounded-full border-2 border-[#00D4AA] border-t-transparent animate-spin" />
              )}
            </div>
          ))}
        </div>

        <p className="mt-6 text-xs text-slate-600">
          Analisando dados em tempo real · Fallback para dados mock se API indisponível
        </p>
      </div>
    </div>
  );
}
