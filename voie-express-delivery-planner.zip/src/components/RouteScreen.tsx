// ═══════════════════════════════════════════════════════════════
// TELA 3 — RESULTADO DA ROTA
// Painel esquerdo: lista de paradas + score
// Painel direito: mapa Leaflet com rota colorida por risco
// ═══════════════════════════════════════════════════════════════

import { useState, useRef } from 'react';
import {
  Navigation, RefreshCw, Download, Share2, AlertTriangle,
  CheckCircle, Clock, Fuel, MapPin, X,
  GripVertical, Info, Thermometer, Wind, Eye
} from 'lucide-react';
import type { RouteLeg } from '../types';
import type { AppStore } from '../store/appStore';
import { MapView } from './MapView';
import { formatDuration, formatDistance, getScoreColor, getPriorityLabel, getVehicleLabel } from '../store/appStore';

interface RouteScreenProps {
  store: AppStore;
}

/** Círculo de score com gradiente animado */
function ScoreCircle({ score }: { score: number }) {
  const color = getScoreColor(score);
  const label = score >= 80 ? 'Excelente' : score >= 60 ? 'Bom' : score >= 40 ? 'Atenção' : 'Alto Risco';
  const circumference = 2 * Math.PI * 44;
  const strokeDash = (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-28 h-28">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
          <circle cx="50" cy="50" r="44" fill="none" stroke="#1E293B" strokeWidth="8" />
          <circle
            cx="50" cy="50" r="44" fill="none"
            stroke={color} strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={`${strokeDash} ${circumference}`}
            style={{ transition: 'stroke-dasharray 1.5s cubic-bezier(0.16, 1, 0.3, 1)', filter: `drop-shadow(0 0 8px ${color})` }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-2xl font-bold" style={{ color }}>{score}</span>
          <span className="text-[10px] text-slate-400">/100</span>
        </div>
      </div>
      <span className="mt-1 text-xs font-semibold" style={{ color }}>{label}</span>
    </div>
  );
}

/** Badge de risco para trecho */
function RiskBadge({ color }: { color: RouteLeg['color'] }) {
  const configs = {
    green: { bg: 'bg-[#00D4AA]/15 text-[#00D4AA]', label: '✓ Seguro' },
    yellow: { bg: 'bg-[#F4A261]/15 text-[#F4A261]', label: '⚠ Atenção' },
    red: { bg: 'bg-[#E63946]/15 text-[#E63946]', label: '🚨 Risco' },
  };
  const cfg = configs[color];
  return (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${cfg.bg}`}>
      {cfg.label}
    </span>
  );
}

/** Modal de detalhes de um trecho */
function LegDetailModal({
  leg, index, onClose
}: { leg: RouteLeg; index: number; onClose: () => void }) {
  const weather = leg.weather;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-md bg-[#1E293B] rounded-2xl border border-white/10 shadow-2xl p-6 animate-scale-in"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-lg text-white font-bold">Trecho {index + 1}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-all">
            <X size={18} />
          </button>
        </div>

        {/* Origem → Destino */}
        <div className="bg-[#0F172A] rounded-xl p-4 mb-4">
          <div className="flex items-start gap-3 mb-3">
            <div className="w-6 h-6 rounded-full bg-[#00D4AA]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs text-[#00D4AA] font-bold">{index + 1}</span>
            </div>
            <div>
              <p className="text-xs text-slate-400">De</p>
              <p className="text-sm text-slate-200 font-medium">{leg.fromStop.address}</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <MapPin size={16} className="text-[#E63946] flex-shrink-0 mt-1" />
            <div>
              <p className="text-xs text-slate-400">Para</p>
              <p className="text-sm text-slate-200 font-medium">{leg.toStop.address}</p>
            </div>
          </div>
        </div>

        {/* Métricas do trecho */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          {[
            { label: 'Distância', value: formatDistance(leg.distanceKm), icon: '📏' },
            { label: 'Tempo', value: formatDuration(leg.durationMin), icon: '⏱️' },
            { label: 'Risco', value: `${leg.riskScore}%`, icon: '⚠️' },
          ].map(m => (
            <div key={m.label} className="bg-[#0B3D2E]/30 rounded-xl p-3 text-center border border-white/5">
              <span className="text-lg">{m.icon}</span>
              <p className="font-bold text-white text-sm mt-1">{m.value}</p>
              <p className="text-[10px] text-slate-500">{m.label}</p>
            </div>
          ))}
        </div>

        {/* Elevação */}
        {(leg.elevationGain !== undefined || leg.elevationLoss !== undefined) && (
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="bg-[#0F172A] rounded-xl p-3 flex items-center gap-2">
              <span className="text-lg">⛰️</span>
              <div>
                <p className="text-xs text-slate-400">Subida</p>
                <p className="text-sm font-semibold text-[#F4A261]">+{Math.round(leg.elevationGain ?? 0)}m</p>
              </div>
            </div>
            <div className="bg-[#0F172A] rounded-xl p-3 flex items-center gap-2">
              <span className="text-lg">🏔️</span>
              <div>
                <p className="text-xs text-slate-400">Descida</p>
                <p className="text-sm font-semibold text-[#00D4AA]">-{Math.round(leg.elevationLoss ?? 0)}m</p>
              </div>
            </div>
          </div>
        )}

        {/* Clima */}
        {weather && (
          <div className="bg-[#0F172A] rounded-xl p-4 mb-4">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-sm font-semibold text-slate-300">🌦️ Condições Climáticas</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center gap-2">
                <Thermometer size={14} className="text-[#F4A261]" />
                <span className="text-sm text-slate-300">{Math.round(weather.temp)}°C</span>
              </div>
              <div className="flex items-center gap-2">
                <Wind size={14} className="text-blue-400" />
                <span className="text-sm text-slate-300">{weather.windSpeed.toFixed(1)} m/s</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye size={14} className="text-slate-400" />
                <span className="text-sm text-slate-300">{(weather.visibility / 1000).toFixed(1)}km vis.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm">💧</span>
                <span className="text-sm text-slate-300">{weather.rainMmPerHour.toFixed(1)}mm/h</span>
              </div>
            </div>
            <div className="mt-2 px-2 py-1 rounded-lg bg-[#1E293B] text-xs text-slate-400 capitalize">
              {weather.description}
            </div>
          </div>
        )}

        {/* Fatores de risco */}
        {leg.riskFactors.length > 0 && (
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-2">Fatores de Risco</p>
            <div className="space-y-1.5">
              {leg.riskFactors.map((f, i) => (
                <div key={i} className="flex items-center gap-2 text-sm text-[#F4A261] bg-[#F4A261]/10 rounded-lg px-3 py-2">
                  {f}
                </div>
              ))}
            </div>
          </div>
        )}

        {leg.riskFactors.length === 0 && (
          <div className="flex items-center gap-2 text-sm text-[#00D4AA] bg-[#00D4AA]/10 rounded-lg px-3 py-2">
            <CheckCircle size={14} />
            Trecho sem fatores de risco identificados
          </div>
        )}
      </div>
    </div>
  );
}

export function RouteScreen({ store }: RouteScreenProps) {
  const { currentRoute, navigate, showToast } = store;
  const [selectedLeg, setSelectedLeg] = useState<number | null>(null);
  const [modalLeg, setModalLeg] = useState<number | null>(null);
  const stopsRef = useRef<HTMLDivElement>(null);

  if (!currentRoute) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center pt-14">
        <div className="text-center text-slate-400">
          <MapPin size={48} className="mx-auto mb-4 opacity-30" />
          <p>Nenhuma rota calculada. Volte ao início.</p>
          <button onClick={() => navigate('home')} className="mt-4 px-4 py-2 rounded-lg bg-[#00D4AA]/20 text-[#00D4AA] text-sm hover:bg-[#00D4AA]/30 transition-all">
            Calcular Rota
          </button>
        </div>
      </div>
    );
  }

  const route = currentRoute;

  const handleExportPDF = () => {
    showToast('Exportação PDF disponível na versão completa.', 'info');
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: 'Voie Express — Rota Calculada',
        text: `Rota com ${route.stops.length} paradas, ${formatDistance(route.totalDistanceKm)}, score ${route.score}/100`,
      }).catch(() => {});
    } else {
      showToast('Link copiado para a área de transferência!', 'success');
    }
  };

  return (
    <div className="bg-[#0F172A] pt-14 pb-16 md:pb-0 flex flex-col" style={{ height: '100vh' }}>
      {/* Modal de detalhe do trecho */}
      {modalLeg !== null && route.legs[modalLeg] && (
        <LegDetailModal
          leg={route.legs[modalLeg]}
          index={modalLeg}
          onClose={() => setModalLeg(null)}
        />
      )}

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* ── PAINEL ESQUERDO ─────────────────────────────────────── */}
        <div className="lg:w-[42%] overflow-y-auto bg-[#0F172A] border-r border-white/10 scroll-thin">
          <div className="p-4 space-y-4">
            {/* Header do painel */}
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl text-white font-bold">Resultado da Rota</h2>
              <button
                onClick={() => navigate('home')}
                className="p-2 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-all"
              >
                <RefreshCw size={16} />
              </button>
            </div>

            {/* Score + Resumo */}
            <div className="bg-[#1E293B] rounded-2xl p-4 border border-white/10">
              <div className="flex items-center gap-6">
                <ScoreCircle score={route.score} />
                <div className="flex-1 space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { icon: <MapPin size={14} />, label: 'Distância', value: formatDistance(route.totalDistanceKm) },
                      { icon: <Clock size={14} />, label: 'Tempo Est.', value: formatDuration(route.totalDurationMin) },
                      { icon: <Fuel size={14} />, label: 'Combustível', value: `${route.estimatedFuelLiters.toFixed(1)}L` },
                      { icon: <AlertTriangle size={14} />, label: 'Alertas', value: `${route.alertCount} trecho(s)` },
                    ].map(item => (
                      <div key={item.label} className="flex items-center gap-1.5">
                        <span className="text-slate-500">{item.icon}</span>
                        <div>
                          <p className="text-[10px] text-slate-500">{item.label}</p>
                          <p className="text-xs font-semibold text-white">{item.value}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Badges de configuração e sazonalidade */}
              <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-white/10">
                <span className="px-2 py-0.5 rounded-full bg-[#0B3D2E] text-[#00D4AA] text-[10px] font-medium">
                  {getPriorityLabel(route.priority)}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-[#0B3D2E] text-[#00D4AA] text-[10px] font-medium">
                  {getVehicleLabel(route.vehicle)}
                </span>
                {route.seasonalBadge && (
                  <span className="px-2 py-0.5 rounded-full bg-[#D4A017]/20 text-[#D4A017] text-[10px] font-medium">
                    {route.seasonalBadge}
                  </span>
                )}
              </div>
            </div>

            {/* Ações */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => navigate('navigate')}
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#0B3D2E] text-white font-semibold text-sm hover:shadow-[0_0_20px_rgba(0,212,170,0.3)] hover:-translate-y-0.5 transition-all"
              >
                <Navigation size={16} />
                Iniciar Navegação
              </button>
              <button
                onClick={() => navigate('home')}
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-[#1E293B] border border-white/10 text-slate-300 font-semibold text-sm hover:border-[#00D4AA]/40 hover:text-[#00D4AA] transition-all"
              >
                <RefreshCw size={16} />
                Nova Simulação
              </button>
              <button
                onClick={handleExportPDF}
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#1E293B] border border-white/10 text-slate-400 text-sm hover:border-white/20 hover:text-white transition-all"
              >
                <Download size={14} />
                Exportar PDF
              </button>
              <button
                onClick={handleShare}
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#1E293B] border border-white/10 text-slate-400 text-sm hover:border-white/20 hover:text-white transition-all"
              >
                <Share2 size={14} />
                Compartilhar
              </button>
            </div>

            {/* Lista de Paradas */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-widest">
                  Sequência de Entregas
                </h3>
                <span className="text-xs text-slate-500">{route.stops.length} paradas</span>
              </div>

              <div ref={stopsRef} className="space-y-2">
                {route.stops.map((stop, i) => {
                  const prevLeg = route.legs[i - 1]; // trecho ATÉ esta parada

                  return (
                    <div
                      key={stop.id}
                      className={`
                        bg-[#1E293B] rounded-xl border p-3 cursor-pointer
                        transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg
                        ${selectedLeg === i ? 'border-[#00D4AA]/50 shadow-[0_0_15px_rgba(0,212,170,0.1)]' : 'border-white/10 hover:border-[#00D4AA]/30'}
                      `}
                      style={{ animationDelay: `${i * 80}ms` }}
                      onClick={() => setSelectedLeg(selectedLeg === i ? null : i)}
                    >
                      <div className="flex items-start gap-3">
                        {/* Número/ícone */}
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-sm"
                          style={{
                            background: i === 0 ? '#00D4AA' : i === route.stops.length - 1 ? '#D4A017' :
                              prevLeg?.color === 'red' ? '#E63946' :
                              prevLeg?.color === 'yellow' ? '#F4A261' : '#1E293B',
                            color: 'white',
                            border: '2px solid rgba(255,255,255,0.2)',
                          }}
                        >
                          {i === 0 ? '🚀' : i === route.stops.length - 1 ? '🏁' : i}
                        </div>

                        {/* Info da parada */}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-slate-200 font-medium truncate">{stop.address}</p>
                          {prevLeg && (
                            <p className="text-xs text-slate-500 mt-0.5">
                              {formatDistance(prevLeg.distanceKm)} · {formatDuration(prevLeg.durationMin)}
                            </p>
                          )}
                          {i === 0 && (
                            <p className="text-xs text-[#00D4AA] mt-0.5">📍 Ponto de partida</p>
                          )}
                        </div>

                        {/* Status do trecho */}
                        <div className="flex flex-col items-end gap-1">
                          {prevLeg && <RiskBadge color={prevLeg.color} />}
                          {(prevLeg?.incidents?.length ?? 0) > 0 && (
                            <span className="text-[10px] text-[#E63946]">
                              ⚠️ {prevLeg!.incidents!.length} incidente(s)
                            </span>
                          )}
                        </div>

                        <button
                          onClick={e => { e.stopPropagation(); setModalLeg(i > 0 ? i - 1 : 0); }}
                          className="p-1.5 rounded-lg hover:bg-white/10 text-slate-500 hover:text-white transition-all flex-shrink-0"
                          title="Ver detalhes"
                        >
                          <Info size={14} />
                        </button>
                      </div>

                      {/* Fatores de risco expandidos */}
                      {selectedLeg === i && prevLeg?.riskFactors && prevLeg.riskFactors.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-white/10 space-y-1">
                          {prevLeg.riskFactors.slice(0, 3).map((f, fi) => (
                            <p key={fi} className="text-xs text-[#F4A261] bg-[#F4A261]/10 px-2 py-1 rounded">{f}</p>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Drag hint */}
            <div className="flex items-center gap-2 text-xs text-slate-600 justify-center py-2">
              <GripVertical size={12} />
              Clique em uma parada para ver detalhes do risco
            </div>
          </div>
        </div>

        {/* ── PAINEL DIREITO — MAPA ───────────────────────────────── */}
        <div className="lg:w-[58%] relative flex-1 lg:flex-none" style={{ minHeight: '400px' }}>
          {/* Legenda do mapa */}
          <div className="absolute top-4 left-4 z-[400] bg-[#1E293B]/90 backdrop-blur-sm rounded-xl border border-white/10 p-3 shadow-xl">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-2">Risco por Trecho</p>
            {[
              { color: '#00D4AA', label: 'Seguro' },
              { color: '#F4A261', label: 'Atenção' },
              { color: '#E63946', label: 'Alto Risco' },
            ].map(item => (
              <div key={item.label} className="flex items-center gap-2 mb-1.5">
                <div className="w-4 h-1.5 rounded-full" style={{ background: item.color }} />
                <span className="text-xs text-slate-300">{item.label}</span>
              </div>
            ))}
          </div>

          {/* Informação do trecho selecionado */}
          {selectedLeg !== null && route.legs[selectedLeg - 1] && (
            <div className="absolute bottom-4 left-4 right-4 z-[400] bg-[#1E293B]/95 backdrop-blur-sm rounded-xl border border-[#00D4AA]/30 p-3 shadow-xl animate-slide-up">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white">Trecho {selectedLeg}</span>
                  <RiskBadge color={route.legs[selectedLeg - 1].color} />
                </div>
                <button onClick={() => setSelectedLeg(null)} className="text-slate-500 hover:text-white">
                  <X size={14} />
                </button>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {formatDistance(route.legs[selectedLeg - 1].distanceKm)} ·
                {formatDuration(route.legs[selectedLeg - 1].durationMin)} ·
                {route.legs[selectedLeg - 1].weather?.description}
              </p>
              {route.legs[selectedLeg - 1].riskFactors.length > 0 && (
                <p className="text-xs text-[#F4A261] mt-1">
                  {route.legs[selectedLeg - 1].riskFactors[0]}
                </p>
              )}
            </div>
          )}

          <MapView
            route={route}
            className="w-full h-full"
            selectedLeg={selectedLeg}
            onStopClick={(i) => {
              setSelectedLeg(i);
              // Scroll para a parada na lista
              const el = stopsRef.current?.children[i];
              el?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }}
          />
        </div>
      </div>
    </div>
  );
}
