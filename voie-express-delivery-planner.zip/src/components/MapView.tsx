// ═══════════════════════════════════════════════════════════════
// MAPA — Leaflet.js com dark mode e rota colorida por risco
// ═══════════════════════════════════════════════════════════════

import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { CalculatedRoute, RouteLeg } from '../types';

// Fix para ícones do Leaflet no Vite
delete (L.Icon.Default.prototype as unknown as Record<string, unknown>)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

interface MapViewProps {
  route: CalculatedRoute;
  className?: string;
  selectedLeg?: number | null;
  onStopClick?: (index: number) => void;
}

const LEG_COLORS = {
  green: '#00D4AA',
  yellow: '#F4A261',
  red: '#E63946',
};

const SCORE_COLORS = {
  green: '#00D4AA',
  yellow: '#D4A017',
  red: '#E63946',
};

/** Cria ícone numerado personalizado para cada parada */
function createStopIcon(index: number, color: string, isStart = false, isEnd = false) {
  const bg = isStart ? '#00D4AA' : isEnd ? '#D4A017' : color;
  const label = isStart ? '🚀' : isEnd ? '🏁' : (index + 1).toString();

  return L.divIcon({
    className: '',
    html: `
      <div style="
        width: 36px; height: 36px;
        background: ${bg};
        border: 3px solid white;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        box-shadow: 0 4px 12px rgba(0,0,0,0.4), 0 0 20px ${bg}60;
        display: flex; align-items: center; justify-content: center;
        cursor: pointer;
        transition: transform 0.2s;
      ">
        <span style="
          transform: rotate(45deg);
          font-size: ${isStart || isEnd ? '14px' : '12px'};
          font-weight: 700;
          color: ${isStart || isEnd ? 'white' : '#0F172A'};
          font-family: 'Inter', sans-serif;
        ">${label}</span>
      </div>
    `,
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    popupAnchor: [0, -36],
  });
}

/** Cria ícone de alerta de incidente */
function createAlertIcon(type: string) {
  const emojis: Record<string, string> = {
    accident: '💥', road_closed: '🚫', construction: '🚧',
    congestion: '🚦', flood: '🌊', pothole: '🕳️', other: '⚠️',
  };
  return L.divIcon({
    className: '',
    html: `
      <div style="
        width: 28px; height: 28px;
        background: #E63946;
        border: 2px solid white;
        border-radius: 6px;
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 2px 8px rgba(230,57,70,0.5);
        font-size: 14px;
      ">${emojis[type] ?? '⚠️'}</div>
    `,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
}

export function MapView({ route, className = '', selectedLeg, onStopClick }: MapViewProps) {
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const layersRef = useRef<L.Layer[]>([]);

  // Inicializa o mapa
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      zoomControl: false,
      attributionControl: true,
    });

    // Tiles OpenStreetMap com filtro dark
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
      className: 'dark-tiles', // Aplicamos filtro via CSS
    }).addTo(map);

    L.control.zoom({ position: 'bottomright' }).addTo(map);

    mapRef.current = map;

    // Invalidate size when container resizes
    const resizeObs = new ResizeObserver(() => {
      map.invalidateSize();
    });
    if (containerRef.current) resizeObs.observe(containerRef.current);

    return () => {
      resizeObs.disconnect();
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Atualiza rota no mapa
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !route) return;

    // Remove camadas anteriores
    layersRef.current.forEach(l => l.remove());
    layersRef.current = [];

    const allCoords: [number, number][] = [];

    // Desenha cada trecho da rota
    route.legs.forEach((leg: RouteLeg, i: number) => {
      const color = LEG_COLORS[leg.color];
      const isSelected = selectedLeg === i;

      if (leg.polyline && leg.polyline.length > 0) {
        // Linha de sombra/glow
        const shadow = L.polyline(leg.polyline, {
          color: color,
          weight: isSelected ? 14 : 10,
          opacity: 0.15,
        }).addTo(map);

        // Linha principal
        const line = L.polyline(leg.polyline, {
          color,
          weight: isSelected ? 6 : 4,
          opacity: isSelected ? 1 : 0.85,
          dashArray: leg.color === 'red' ? '8 4' : undefined,
        }).addTo(map);

        line.bindTooltip(`
          <div style="font-family: Inter, sans-serif; font-size: 12px;">
            <strong>Trecho ${i + 1}</strong><br>
            📏 ${leg.distanceKm.toFixed(1)}km · ⏱ ${Math.round(leg.durationMin)}min<br>
            ${leg.color === 'red' ? '⚠️ Risco alto' : leg.color === 'yellow' ? '⚠️ Atenção' : '✅ Seguro'}
          </div>
        `, { sticky: true, className: 'leaflet-tooltip-dark' });

        leg.polyline.forEach(c => allCoords.push(c));
        layersRef.current.push(shadow, line);
      } else {
        // Fallback: linha reta
        if (leg.fromStop.coordinate && leg.toStop.coordinate) {
          const from: [number, number] = [leg.fromStop.coordinate.lat, leg.fromStop.coordinate.lon];
          const to: [number, number] = [leg.toStop.coordinate.lat, leg.toStop.coordinate.lon];
          const line = L.polyline([from, to], { color, weight: 4, opacity: 0.85 }).addTo(map);
          layersRef.current.push(line);
          allCoords.push(from, to);
        }
      }

      // Incidentes no trecho
      leg.incidents?.forEach(inc => {
        const marker = L.marker([inc.lat, inc.lon], { icon: createAlertIcon(inc.type) })
          .addTo(map)
          .bindTooltip(`<strong>${inc.description}</strong>`, { className: 'leaflet-tooltip-dark' });
        layersRef.current.push(marker);
      });
    });

    // Pins de paradas
    route.stops.forEach((stop, i) => {
      if (!stop.coordinate) return;
      const isStart = i === 0;
      const isEnd = i === route.stops.length - 1;
      const legColor = route.legs[i - 1]?.color ?? 'green';
      const pinColor = SCORE_COLORS[legColor] ?? '#00D4AA';

      const marker = L.marker(
        [stop.coordinate.lat, stop.coordinate.lon],
        { icon: createStopIcon(i, pinColor, isStart, isEnd) }
      )
        .addTo(map)
        .bindPopup(`
          <div style="font-family: Inter, sans-serif; min-width: 200px;">
            <div style="font-weight: 700; margin-bottom: 6px; color: #0F172A;">
              📍 Parada ${i + 1}${isStart ? ' — Origem' : isEnd ? ' — Destino Final' : ''}
            </div>
            <div style="font-size: 12px; color: #475569; line-height: 1.5;">
              ${stop.address}
            </div>
            ${i > 0 && route.legs[i - 1] ? `
              <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #e2e8f0; font-size: 12px;">
                📏 ${route.legs[i - 1].distanceKm.toFixed(1)}km ·
                ⏱ ${Math.round(route.legs[i - 1].durationMin)}min
              </div>
            ` : ''}
          </div>
        `);

      if (onStopClick) {
        marker.on('click', () => onStopClick(i));
      }

      allCoords.push([stop.coordinate.lat, stop.coordinate.lon]);
      layersRef.current.push(marker);
    });

    // Centraliza o mapa nos pontos da rota
    if (allCoords.length > 0) {
      const bounds = L.latLngBounds(allCoords);
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
    }
  }, [route, selectedLeg, onStopClick]);

  return (
    <>
      <style>{`
        .dark-tiles {
          filter: invert(100%) hue-rotate(180deg) brightness(85%) contrast(85%) saturate(0.8);
        }
        .leaflet-container {
          background: #0F172A;
          font-family: 'Inter', sans-serif;
        }
        .leaflet-tooltip-dark {
          background: #1E293B !important;
          border: 1px solid rgba(255,255,255,0.1) !important;
          color: #F1F5F9 !important;
          font-family: 'Inter', sans-serif !important;
          font-size: 12px !important;
          border-radius: 8px !important;
          box-shadow: 0 4px 20px rgba(0,0,0,0.5) !important;
        }
        .leaflet-popup-content-wrapper {
          background: white !important;
          border-radius: 12px !important;
          box-shadow: 0 8px 30px rgba(0,0,0,0.3) !important;
        }
        .leaflet-popup-tip {
          background: white !important;
        }
        .leaflet-control-attribution {
          background: rgba(15,23,42,0.8) !important;
          color: rgba(241,245,249,0.5) !important;
          font-size: 9px !important;
        }
        .leaflet-control-attribution a { color: rgba(0,212,170,0.7) !important; }
        .leaflet-control-zoom a {
          background: #1E293B !important;
          color: #F1F5F9 !important;
          border-color: rgba(255,255,255,0.1) !important;
        }
        .leaflet-control-zoom a:hover {
          background: #00D4AA20 !important;
          color: #00D4AA !important;
        }
      `}</style>
      <div ref={containerRef} className={`w-full h-full rounded-xl overflow-hidden ${className}`} />
    </>
  );
}
