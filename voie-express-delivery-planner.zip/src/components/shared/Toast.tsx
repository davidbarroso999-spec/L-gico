// ═══════════════════════════════════════════════════════════════
// TOAST — Notificação visual animada (substitui OneSignal no MVP)
// ═══════════════════════════════════════════════════════════════

import { useEffect, useState } from 'react';
import { CheckCircle, AlertTriangle, XCircle, Info, X } from 'lucide-react';

interface ToastProps {
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  onClose: () => void;
}

const ICONS = {
  success: <CheckCircle size={18} />,
  error: <XCircle size={18} />,
  warning: <AlertTriangle size={18} />,
  info: <Info size={18} />,
};

const COLORS = {
  success: 'border-[#00D4AA] bg-[#00D4AA]/10 text-[#00D4AA]',
  error: 'border-[#E63946] bg-[#E63946]/10 text-[#E63946]',
  warning: 'border-[#F4A261] bg-[#F4A261]/10 text-[#F4A261]',
  info: 'border-[#D4A017] bg-[#D4A017]/10 text-[#D4A017]',
};

export function Toast({ message, type, onClose }: ToastProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Animação de entrada
    requestAnimationFrame(() => setVisible(true));
  }, []);

  const handleClose = () => {
    setVisible(false);
    setTimeout(onClose, 300);
  };

  return (
    <div
      className={`
        fixed top-5 right-5 z-[9999] flex items-center gap-3 px-4 py-3 rounded-xl
        border backdrop-blur-sm shadow-2xl max-w-sm
        transition-all duration-300 ease-out
        ${COLORS[type]}
        ${visible ? 'translate-x-0 opacity-100' : 'translate-x-8 opacity-0'}
      `}
    >
      <span className="flex-shrink-0">{ICONS[type]}</span>
      <p className="text-sm font-medium text-slate-100">{message}</p>
      <button onClick={handleClose} className="ml-auto opacity-60 hover:opacity-100 transition-opacity">
        <X size={16} />
      </button>
    </div>
  );
}
