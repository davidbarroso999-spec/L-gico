// ═══════════════════════════════════════════════════════════════
// STATUS BAR — Barra de status com indicador online/offline
// ═══════════════════════════════════════════════════════════════

import { Wifi, WifiOff, RefreshCw, Package } from 'lucide-react';
import type { Screen } from '../../types';

interface StatusBarProps {
  isOnline: boolean;
  screen: Screen;
  onNavigate: (screen: Screen) => void;
}

export function StatusBar({ isOnline, screen, onNavigate }: StatusBarProps) {
  const navItems: { id: Screen; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Início', icon: <Package size={16} /> },
    { id: 'route', label: 'Rota', icon: <span className="text-xs">🗺️</span> },
    { id: 'navigate', label: 'Navegar', icon: <span className="text-xs">🧭</span> },
    { id: 'dashboard', label: 'Dashboard', icon: <span className="text-xs">📊</span> },
    { id: 'settings', label: 'Config', icon: <span className="text-xs">⚙️</span> },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0B3D2E] border-b border-white/10 shadow-lg">
      <div className="flex items-center justify-between px-4 py-2.5">
        {/* Logo */}
        <div className="flex items-center gap-2.5">
          <div className="relative w-8 h-8">
            <div className="w-8 h-8 rounded-lg bg-[#00D4AA]/20 flex items-center justify-center animate-pulse-logo">
              <span className="text-lg">📦</span>
            </div>
          </div>
          <div>
            <h1 className="font-display text-white font-bold text-base leading-none">Voie Express</h1>
            <p className="text-[10px] text-[#00D4AA] tracking-widest uppercase">Planejador Inteligente</p>
          </div>
        </div>

        {/* Nav Desktop */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`
                flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium
                transition-all duration-200
                ${screen === item.id
                  ? 'bg-[#00D4AA]/20 text-[#00D4AA]'
                  : 'text-white/60 hover:text-white hover:bg-white/10'
                }
              `}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        {/* Status Online */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            {isOnline ? (
              <>
                <div className="w-2 h-2 rounded-full bg-[#00D4AA] shadow-[0_0_8px_#00D4AA] animate-ping-slow" />
                <Wifi size={14} className="text-[#00D4AA]" />
                <span className="text-[11px] text-[#00D4AA] font-medium hidden sm:block">Online</span>
              </>
            ) : (
              <>
                <div className="w-2 h-2 rounded-full bg-[#E63946] animate-breath" />
                <WifiOff size={14} className="text-[#E63946]" />
                <span className="text-[11px] text-[#E63946] font-medium hidden sm:block">Offline</span>
              </>
            )}
          </div>
          {isOnline && (
            <button className="p-1.5 rounded-lg text-white/40 hover:text-[#00D4AA] hover:bg-white/10 transition-all">
              <RefreshCw size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Nav Mobile - Bottom */}
    </header>
  );
}

// Bottom nav for mobile
export function BottomNav({ screen, onNavigate }: { screen: Screen; onNavigate: (s: Screen) => void }) {
  const navItems: { id: Screen; label: string; emoji: string }[] = [
    { id: 'home', label: 'Início', emoji: '🏠' },
    { id: 'route', label: 'Rota', emoji: '🗺️' },
    { id: 'navigate', label: 'Navegar', emoji: '🧭' },
    { id: 'dashboard', label: 'Stats', emoji: '📊' },
    { id: 'settings', label: 'Config', emoji: '⚙️' },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0B3D2E] border-t border-white/10 flex">
      {navItems.map(item => (
        <button
          key={item.id}
          onClick={() => onNavigate(item.id)}
          className={`
            flex-1 flex flex-col items-center py-2 gap-0.5
            transition-all duration-200
            ${screen === item.id ? 'text-[#00D4AA]' : 'text-white/50'}
          `}
        >
          <span className="text-lg">{item.emoji}</span>
          <span className="text-[9px] font-medium">{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
