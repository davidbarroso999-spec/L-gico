// ═══════════════════════════════════════════════════════════════
// TELA 5 — DASHBOARD / HISTÓRICO
// KPIs com count-up, gráficos Chart.js, heatmap de ocorrências
// ═══════════════════════════════════════════════════════════════

import { useEffect, useRef, useState } from 'react';
import { Chart, registerables } from 'chart.js';
import { TrendingUp, Package, Clock, AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react';
import type { AppStore } from '../store/appStore';
import { formatDistance, formatDuration } from '../store/appStore';

Chart.register(...registerables);

interface DashboardScreenProps {
  store: AppStore;
}

// ── Hook de count-up ────────────────────────────────────────────
function useCountUp(target: number, duration = 1500) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    const start = Date.now();
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      // ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(eased * target));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [target, duration]);
  return value;
}

// ── KPI Card ────────────────────────────────────────────────────
function KPICard({
  icon, label, value, unit, color, subtitle
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  unit: string;
  color: string;
  subtitle?: string;
}) {
  const animated = useCountUp(value);
  return (
    <div className="bg-[#1E293B] rounded-2xl border border-white/10 p-5 hover:border-white/20 hover:-translate-y-1 hover:shadow-xl transition-all duration-200 group">
      <div className="flex items-start justify-between mb-3">
        <div className="p-2.5 rounded-xl" style={{ background: `${color}20` }}>
          <span style={{ color }}>{icon}</span>
        </div>
        <TrendingUp size={14} className="text-slate-600 group-hover:text-[#00D4AA] transition-colors" />
      </div>
      <div className="flex items-end gap-1 mb-1">
        <span className="font-display text-3xl font-bold" style={{ color }}>{animated}</span>
        <span className="text-slate-400 text-sm mb-1">{unit}</span>
      </div>
      <p className="text-xs text-slate-400 font-medium">{label}</p>
      {subtitle && <p className="text-xs text-slate-600 mt-0.5">{subtitle}</p>}
    </div>
  );
}

// ── Dados mock do histórico ─────────────────────────────────────
const MOCK_HISTORY = [
  { id: '1', date: '2025-01-20', addresses: ['Centro', 'Adrianópolis', 'Aleixo'], score: 88, km: 23.4, deliveries: 3, status: 'completed' as const },
  { id: '2', date: '2025-01-19', addresses: ['Flores', 'Compensa', 'Cidade Nova'], score: 72, km: 31.2, deliveries: 3, status: 'completed' as const },
  { id: '3', date: '2025-01-18', addresses: ['Centro', 'Flores'], score: 55, km: 12.8, deliveries: 1, status: 'failed' as const },
  { id: '4', date: '2025-01-17', addresses: ['Aleixo', 'Adrianópolis', 'Flores', 'Centro'], score: 91, km: 38.7, deliveries: 4, status: 'completed' as const },
  { id: '5', date: '2025-01-16', addresses: ['Compensa', 'Cidade Nova', 'Centro'], score: 67, km: 28.1, deliveries: 2, status: 'completed' as const },
];

const MOCK_CHART_DATA = {
  labels: ['Jan 14', 'Jan 15', 'Jan 16', 'Jan 17', 'Jan 18', 'Jan 19', 'Jan 20'],
  routes: [3, 5, 4, 6, 3, 5, 4],
  km: [45, 82, 67, 94, 38, 71, 58],
  scores: [75, 82, 68, 91, 55, 72, 88],
};

export function DashboardScreen({ store }: DashboardScreenProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'map'>('overview');
  const { currentRoute, navigate } = store;

  // KPIs calculados (mock + rota atual se existir)
  const totalKm = MOCK_HISTORY.reduce((s, r) => s + r.km, 0) + (currentRoute?.totalDistanceKm ?? 0);
  const totalDeliveries = MOCK_HISTORY.reduce((s, r) => s + r.deliveries, 0);
  const completed = MOCK_HISTORY.filter(r => r.status === 'completed').length;
  const onTimeRate = Math.round((completed / MOCK_HISTORY.length) * 100);
  const avgScore = Math.round(MOCK_HISTORY.reduce((s, r) => s + r.score, 0) / MOCK_HISTORY.length);

  // Inicializa o gráfico de linha
  useEffect(() => {
    if (!chartRef.current || activeTab !== 'overview') return;

    // Destrói gráfico anterior
    chartInstance.current?.destroy();

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: MOCK_CHART_DATA.labels,
        datasets: [
          {
            label: 'Score de Rota',
            data: MOCK_CHART_DATA.scores,
            borderColor: '#00D4AA',
            backgroundColor: 'rgba(0,212,170,0.1)',
            borderWidth: 2.5,
            pointBackgroundColor: '#00D4AA',
            pointRadius: 4,
            pointHoverRadius: 6,
            fill: true,
            tension: 0.4,
          },
          {
            label: 'KM Percorridos',
            data: MOCK_CHART_DATA.km,
            borderColor: '#D4A017',
            backgroundColor: 'rgba(212,160,23,0.05)',
            borderWidth: 2,
            pointBackgroundColor: '#D4A017',
            pointRadius: 4,
            pointHoverRadius: 6,
            fill: false,
            tension: 0.4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: { color: '#94A3B8', font: { family: 'Inter', size: 12 }, padding: 16 },
          },
          tooltip: {
            backgroundColor: '#1E293B',
            borderColor: 'rgba(255,255,255,0.1)',
            borderWidth: 1,
            titleColor: '#F1F5F9',
            bodyColor: '#94A3B8',
            padding: 12,
          },
        },
        scales: {
          x: {
            grid: { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#64748B', font: { family: 'Inter', size: 11 } },
          },
          y: {
            grid: { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#64748B', font: { family: 'Inter', size: 11 } },
          },
        },
        animation: { duration: 800, easing: 'easeInOutQuart' },
      },
    });

    return () => { chartInstance.current?.destroy(); };
  }, [activeTab]);

  return (
    <div className="min-h-screen bg-[#0F172A] pt-14 pb-16 md:pb-0">
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="font-display text-2xl text-white font-bold">Dashboard</h2>
            <p className="text-slate-400 text-sm">Análise de desempenho de entregas</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#1E293B] border border-white/10 text-slate-400 text-sm hover:border-[#00D4AA]/40 hover:text-[#00D4AA] transition-all">
            <RefreshCw size={14} />
            Sincronizar
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-[#1E293B] rounded-xl p-1 mb-6 w-fit">
          {[
            { id: 'overview', label: '📊 Visão Geral' },
            { id: 'history', label: '📋 Histórico' },
            { id: 'map', label: '🗺️ Heatmap' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`
                px-4 py-2 rounded-lg text-sm font-medium transition-all
                ${activeTab === tab.id
                  ? 'bg-[#00D4AA]/20 text-[#00D4AA]'
                  : 'text-slate-400 hover:text-white'
                }
              `}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-6 animate-fade-in">
            {/* KPIs */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              <KPICard
                icon={<Package size={20} />}
                label="KM Total"
                value={Math.round(totalKm)}
                unit="km"
                color="#00D4AA"
                subtitle="Últimos 7 dias"
              />
              <KPICard
                icon={<CheckCircle size={20} />}
                label="Entregas"
                value={totalDeliveries}
                unit="pts"
                color="#D4A017"
                subtitle="Confirmadas"
              />
              <KPICard
                icon={<Clock size={20} />}
                label="Tempo Médio"
                value={52}
                unit="min"
                color="#3B82F6"
                subtitle="Por rota"
              />
              <KPICard
                icon={<AlertTriangle size={20} />}
                label="Ocorrências"
                value={4}
                unit="rep."
                color="#F4A261"
                subtitle="Reportadas"
              />
              <KPICard
                icon={<TrendingUp size={20} />}
                label="Taxa No-Prazo"
                value={onTimeRate}
                unit="%"
                color="#00D4AA"
                subtitle={`Score médio: ${avgScore}`}
              />
            </div>

            {/* Gráfico */}
            <div className="bg-[#1E293B] rounded-2xl border border-white/10 p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-white font-semibold">Desempenho de Rotas</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Score e distância nos últimos 7 dias</p>
                </div>
                <span className="text-xs text-slate-500 px-2 py-1 rounded-lg bg-[#0F172A]">Jan 14–20</span>
              </div>
              <div className="h-56">
                <canvas ref={chartRef} />
              </div>
            </div>

            {/* Rota atual */}
            {currentRoute && (
              <div className="bg-gradient-to-r from-[#0B3D2E] to-[#1E293B] rounded-2xl border border-[#00D4AA]/20 p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs text-[#00D4AA] font-semibold uppercase tracking-widest">Rota Atual</span>
                    <h3 className="text-white font-bold mt-0.5">{currentRoute.stops.length} paradas calculadas</h3>
                    <p className="text-sm text-slate-400 mt-1">
                      {formatDistance(currentRoute.totalDistanceKm)} · {formatDuration(currentRoute.totalDurationMin)} · Score {currentRoute.score}/100
                    </p>
                  </div>
                  <button
                    onClick={() => navigate('route')}
                    className="px-4 py-2 rounded-xl bg-[#00D4AA] text-[#0B3D2E] font-bold text-sm hover:bg-[#00D4AA]/90 transition-all"
                  >
                    Ver Rota
                  </button>
                </div>
              </div>
            )}

            {/* Resumo por tipo de ocorrência */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { emoji: '🕳️', label: 'Buracos', count: 2, color: '#92400E' },
                { emoji: '🌊', label: 'Alagamentos', count: 1, color: '#3B82F6' },
                { emoji: '🚫', label: 'Bloqueios', count: 0, color: '#E63946' },
                { emoji: '💥', label: 'Acidentes', count: 1, color: '#E63946' },
              ].map(item => (
                <div key={item.label} className="bg-[#1E293B] rounded-xl border border-white/10 p-4 flex items-center gap-3">
                  <span className="text-2xl">{item.emoji}</span>
                  <div>
                    <p className="text-lg font-bold" style={{ color: item.color }}>{item.count}</p>
                    <p className="text-xs text-slate-400">{item.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-3 animate-fade-in">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">Rotas Anteriores</h3>
              <span className="text-xs text-slate-500">{MOCK_HISTORY.length} rotas</span>
            </div>

            {MOCK_HISTORY.map((route, i) => (
              <div
                key={route.id}
                className="bg-[#1E293B] rounded-xl border border-white/10 p-4 hover:border-[#00D4AA]/30 hover:-translate-y-0.5 transition-all cursor-pointer"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm"
                      style={{
                        background: route.score >= 80 ? '#00D4AA20' : route.score >= 60 ? '#F4A26120' : '#E6394620',
                        color: route.score >= 80 ? '#00D4AA' : route.score >= 60 ? '#F4A261' : '#E63946',
                        border: `2px solid ${route.score >= 80 ? '#00D4AA40' : route.score >= 60 ? '#F4A26140' : '#E6394640'}`,
                      }}
                    >
                      {route.score}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">
                        {route.addresses.join(' → ')}
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {route.date} · {route.km}km · {route.deliveries} entregas
                      </p>
                    </div>
                  </div>
                  <span className={`
                    px-2 py-0.5 rounded-full text-xs font-semibold
                    ${route.status === 'completed'
                      ? 'bg-[#00D4AA]/15 text-[#00D4AA]'
                      : 'bg-[#E63946]/15 text-[#E63946]'
                    }
                  `}>
                    {route.status === 'completed' ? '✓ Concluída' : '✗ Falha'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'map' && (
          <div className="animate-fade-in">
            <div className="bg-[#1E293B] rounded-2xl border border-white/10 p-6 text-center">
              <div className="text-5xl mb-4">🗺️</div>
              <h3 className="text-white font-bold text-lg mb-2">Heatmap de Ocorrências</h3>
              <p className="text-slate-400 text-sm mb-4">
                Visualização de pontos problemáticos acumulados das rotas reportadas.
              </p>

              <div className="grid grid-cols-3 gap-3 mb-6">
                {[
                  { emoji: '🕳️', label: 'Buracos', color: '#92400E', pos: '15%, 30%' },
                  { emoji: '🌊', label: 'Alagamentos', color: '#3B82F6', pos: '60%, 45%' },
                  { emoji: '🚫', label: 'Bloqueios', color: '#E63946', pos: '80%, 20%' },
                ].map(item => (
                  <div key={item.label} className="bg-[#0F172A] rounded-xl p-3 flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: item.color }} />
                    <span className="text-xs text-slate-300">{item.emoji} {item.label}</span>
                  </div>
                ))}
              </div>

              {/* Mapa simplificado com marcadores de ocorrência */}
              <div className="relative bg-[#0F172A] rounded-xl h-48 overflow-hidden border border-white/10">
                <div className="absolute inset-0 opacity-20"
                  style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, #00D4AA 0%, transparent 50%), radial-gradient(circle at 80% 20%, #E63946 0%, transparent 40%)' }}
                />
                {/* Pontos de ocorrência mock */}
                {[
                  { top: '30%', left: '15%', color: '#92400E', emoji: '🕳️' },
                  { top: '45%', left: '60%', color: '#3B82F6', emoji: '🌊' },
                  { top: '20%', left: '80%', color: '#E63946', emoji: '🚫' },
                  { top: '65%', left: '35%', color: '#92400E', emoji: '🕳️' },
                  { top: '50%', left: '70%', color: '#E63946', emoji: '💥' },
                ].map((p, i) => (
                  <div
                    key={i}
                    className="absolute w-6 h-6 rounded-lg flex items-center justify-center text-sm border border-white/30 shadow-lg"
                    style={{ top: p.top, left: p.left, background: `${p.color}40`, transform: 'translate(-50%, -50%)' }}
                  >
                    {p.emoji}
                  </div>
                ))}
                <div className="absolute bottom-2 right-2 text-xs text-slate-600">Área de Manaus — AM</div>
              </div>

              <p className="text-xs text-slate-600 mt-4">
                Integração com Leaflet Heatmap disponível na versão completa
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
