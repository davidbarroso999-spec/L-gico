// ═══════════════════════════════════════════════════════════════
// TELA 6 — CONFIGURAÇÕES
// Chaves de API, preferências, cache e informações do sistema
// ═══════════════════════════════════════════════════════════════

import { useState } from 'react';
import {
  Key, AlertTriangle, Eye, EyeOff, Save, Trash2,
  RefreshCw, Info, ChevronDown, ChevronUp
} from 'lucide-react';
import type { AppStore } from '../store/appStore';
import type { Priority, VehicleType } from '../types';
import { cleanExpiredCache } from '../services/db';

interface SettingsScreenProps {
  store: AppStore;
}

function ApiKeyInput({
  label, value, onChange, placeholder, service, docsUrl
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  service: string;
  docsUrl: string;
}) {
  const [show, setShow] = useState(false);
  const isEmpty = !value || value === '[INSIRA_SUA_CHAVE]';

  return (
    <div className="bg-[#0F172A] rounded-xl border border-white/10 p-4">
      <div className="flex items-center justify-between mb-2">
        <div>
          <label className="text-sm font-semibold text-white">{label}</label>
          <a
            href={docsUrl}
            target="_blank"
            rel="noreferrer"
            className="ml-2 text-xs text-[#00D4AA] hover:underline"
          >
            {service} docs →
          </a>
        </div>
        <div className={`w-2 h-2 rounded-full ${isEmpty ? 'bg-[#E63946]' : 'bg-[#00D4AA] shadow-[0_0_6px_#00D4AA]'}`} />
      </div>
      <div className="relative">
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full bg-[#1E293B] border border-white/10 rounded-lg px-4 py-2.5 pr-10 text-slate-200 text-sm placeholder:text-slate-600 focus:outline-none focus:border-[#00D4AA]/50 font-mono"
        />
        <button
          onClick={() => setShow(!show)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"
        >
          {show ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
      </div>
    </div>
  );
}

export function SettingsScreen({ store }: SettingsScreenProps) {
  const { settings, updateSettings, showToast } = store;
  const [localSettings, setLocalSettings] = useState(settings);
  const [showApiSection, setShowApiSection] = useState(true);
  const [showPrefsSection, setShowPrefsSection] = useState(true);

  const handleSave = () => {
    updateSettings(localSettings);
    showToast('Configurações salvas!', 'success');
  };

  const handleClearCache = async () => {
    await cleanExpiredCache();
    localStorage.removeItem('voie_route_cache');
    showToast('Cache limpo com sucesso!', 'success');
  };

  const API_CONFIGS = [
    {
      label: 'OpenRouteService',
      key: 'orsKey' as const,
      service: 'ORS',
      docsUrl: 'https://openrouteservice.org/dev/#/api-docs',
      placeholder: 'eyJvcmciOiI...',
    },
    {
      label: 'OpenWeatherMap',
      key: 'openweatherKey' as const,
      service: 'OpenWeather',
      docsUrl: 'https://openweathermap.org/api',
      placeholder: 'a46d5eac...',
    },
    {
      label: 'Visual Crossing',
      key: 'visualcrossingKey' as const,
      service: 'VisualCrossing',
      docsUrl: 'https://www.visualcrossing.com/weather-api',
      placeholder: 'VBC92VXW...',
    },
    {
      label: 'TomTom Traffic',
      key: 'tomtomKey' as const,
      service: 'TomTom',
      docsUrl: 'https://developer.tomtom.com/traffic-api',
      placeholder: 'RTvaCPgT...',
    },
  ];

  const PRIORITIES: { id: Priority; label: string }[] = [
    { id: 'fastest', label: '⚡ Mais Rápido' },
    { id: 'shortest', label: '📏 Mais Curto' },
    { id: 'economic', label: '🌿 Mais Econômico' },
    { id: 'safest', label: '🛡️ Mais Seguro' },
    { id: 'balanced', label: '⚖️ Equilibrado' },
  ];

  const VEHICLES: { id: VehicleType; label: string }[] = [
    { id: 'car', label: '🚗 Carro' },
    { id: 'motorcycle', label: '🏍️ Moto' },
    { id: 'truck', label: '🚛 Caminhão' },
    { id: 'van', label: '🚐 Van' },
    { id: 'boat', label: '⛵ Barco' },
  ];

  return (
    <div className="min-h-screen bg-[#0F172A] pt-14 pb-16 md:pb-0">
      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <h2 className="font-display text-2xl text-white font-bold">Configurações</h2>
          <p className="text-slate-400 text-sm">Gerencie chaves de API, preferências e cache</p>
        </div>

        {/* Aviso de segurança */}
        <div className="flex items-start gap-3 p-4 rounded-xl bg-[#F4A261]/10 border border-[#F4A261]/30 mb-6">
          <AlertTriangle size={16} className="text-[#F4A261] mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm font-semibold text-[#F4A261]">Aviso de Segurança</p>
            <p className="text-xs text-[#F4A261]/80 mt-0.5">
              As chaves de API são armazenadas no localStorage do navegador.
              Para produção, use variáveis de ambiente no servidor ou um proxy seguro.
              Nunca exponha chaves no código-fonte público.
            </p>
          </div>
        </div>

        {/* Seção de Chaves de API */}
        <div className="bg-[#1E293B] rounded-2xl border border-white/10 mb-4 overflow-hidden">
          <button
            onClick={() => setShowApiSection(!showApiSection)}
            className="w-full flex items-center justify-between p-5 hover:bg-white/5 transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#00D4AA]/20">
                <Key size={16} className="text-[#00D4AA]" />
              </div>
              <div className="text-left">
                <h3 className="text-white font-semibold">Chaves de API</h3>
                <p className="text-xs text-slate-500">Configure as integrações com serviços externos</p>
              </div>
            </div>
            {showApiSection ? <ChevronUp size={16} className="text-slate-500" /> : <ChevronDown size={16} className="text-slate-500" />}
          </button>

          {showApiSection && (
            <div className="px-5 pb-5 space-y-3">
              {API_CONFIGS.map(api => (
                <ApiKeyInput
                  key={api.key}
                  label={api.label}
                  value={localSettings[api.key]}
                  onChange={v => setLocalSettings(s => ({ ...s, [api.key]: v }))}
                  placeholder={api.placeholder}
                  service={api.service}
                  docsUrl={api.docsUrl}
                />
              ))}

              {/* INMET (sem chave) */}
              <div className="bg-[#0F172A] rounded-xl border border-white/10 p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-semibold text-white">INMET</label>
                    <a
                      href="https://apiprevmet3.inmet.gov.br"
                      target="_blank"
                      rel="noreferrer"
                      className="ml-2 text-xs text-[#00D4AA] hover:underline"
                    >
                      INMET docs →
                    </a>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-[#00D4AA] shadow-[0_0_6px_#00D4AA]" />
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  🇧🇷 API oficial brasileira — não requer chave. Usa código IBGE da cidade.
                </p>
              </div>

              {/* OpenTopoData (sem chave) */}
              <div className="bg-[#0F172A] rounded-xl border border-white/10 p-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-semibold text-white">OpenTopoData (SRTM)</label>
                  <div className="w-2 h-2 rounded-full bg-[#00D4AA] shadow-[0_0_6px_#00D4AA]" />
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  ⛰️ Dados de elevação gratuitos — não requer chave.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Seção de Preferências */}
        <div className="bg-[#1E293B] rounded-2xl border border-white/10 mb-4 overflow-hidden">
          <button
            onClick={() => setShowPrefsSection(!showPrefsSection)}
            className="w-full flex items-center justify-between p-5 hover:bg-white/5 transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#D4A017]/20">
                <span className="text-[#D4A017]">⚙️</span>
              </div>
              <div className="text-left">
                <h3 className="text-white font-semibold">Preferências Padrão</h3>
                <p className="text-xs text-slate-500">Prioridade, veículo e filtros de rota</p>
              </div>
            </div>
            {showPrefsSection ? <ChevronUp size={16} className="text-slate-500" /> : <ChevronDown size={16} className="text-slate-500" />}
          </button>

          {showPrefsSection && (
            <div className="px-5 pb-5 space-y-4">
              {/* Prioridade Padrão */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-widest block mb-2">
                  Prioridade Padrão
                </label>
                <div className="flex flex-wrap gap-2">
                  {PRIORITIES.map(p => (
                    <button
                      key={p.id}
                      onClick={() => setLocalSettings(s => ({ ...s, defaultPriority: p.id }))}
                      className={`
                        px-3 py-2 rounded-lg text-sm font-medium border transition-all
                        ${localSettings.defaultPriority === p.id
                          ? 'bg-[#00D4AA]/20 border-[#00D4AA]/50 text-[#00D4AA]'
                          : 'bg-[#0F172A] border-white/10 text-slate-400 hover:border-white/20'
                        }
                      `}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Veículo Padrão */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-widest block mb-2">
                  Veículo Padrão
                </label>
                <div className="flex flex-wrap gap-2">
                  {VEHICLES.map(v => (
                    <button
                      key={v.id}
                      onClick={() => setLocalSettings(s => ({ ...s, defaultVehicle: v.id }))}
                      className={`
                        px-3 py-2 rounded-lg text-sm font-medium border transition-all
                        ${localSettings.defaultVehicle === v.id
                          ? 'bg-[#0B3D2E] border-[#00D4AA]/50 text-[#00D4AA]'
                          : 'bg-[#0F172A] border-white/10 text-slate-400 hover:border-white/20'
                        }
                      `}
                    >
                      {v.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Checkboxes de filtro */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-widest block mb-2">
                  Filtros de Rota Padrão
                </label>
                <div className="space-y-2">
                  {[
                    { key: 'avoidDirt' as const, label: '🌱 Evitar ruas de terra' },
                    { key: 'avoidFlood' as const, label: '🌊 Evitar alagamentos' },
                    { key: 'avoidSlopes' as const, label: '⛰️ Evitar ladeiras íngremes' },
                    { key: 'avoidNoSignal' as const, label: '📵 Evitar áreas sem sinal' },
                    { key: 'preferAsphalt' as const, label: '🛣️ Priorizar asfalto' },
                  ].map(opt => (
                    <label
                      key={opt.key}
                      className={`
                        flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all
                        ${localSettings[opt.key]
                          ? 'bg-[#0B3D2E]/50 border-[#00D4AA]/30'
                          : 'bg-[#0F172A] border-white/10 hover:border-white/20'
                        }
                      `}
                    >
                      <input type="checkbox" className="sr-only" checked={localSettings[opt.key]}
                        onChange={e => setLocalSettings(s => ({ ...s, [opt.key]: e.target.checked }))} />
                      <div className={`w-5 h-5 rounded flex items-center justify-center border-2 transition-all ${localSettings[opt.key] ? 'bg-[#00D4AA] border-[#00D4AA]' : 'border-white/30'}`}>
                        {localSettings[opt.key] && <span className="text-white text-xs font-bold">✓</span>}
                      </div>
                      <span className="text-sm text-slate-300">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Ações do sistema */}
        <div className="bg-[#1E293B] rounded-2xl border border-white/10 mb-4 p-5 space-y-3">
          <h3 className="text-white font-semibold flex items-center gap-2">
            <span>🔧</span> Sistema
          </h3>

          <button
            onClick={handleClearCache}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[#0F172A] border border-white/10 text-slate-300 hover:border-[#F4A261]/40 hover:text-[#F4A261] transition-all text-sm"
          >
            <Trash2 size={16} />
            Limpar Cache (clima, elevação, incidentes)
          </button>

          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[#0F172A] border border-white/10 text-slate-300 hover:border-[#00D4AA]/40 hover:text-[#00D4AA] transition-all text-sm">
            <RefreshCw size={16} />
            Sincronizar Ocorrências Pendentes
          </button>

          <div className="bg-[#0F172A] rounded-xl p-4 border border-white/5">
            <div className="flex items-start gap-2">
              <Info size={14} className="text-slate-500 mt-0.5 flex-shrink-0" />
              <div className="text-xs text-slate-500 space-y-1">
                <p><strong className="text-slate-400">Versão:</strong> Voie Express MVP v1.0.0</p>
                <p><strong className="text-slate-400">Banco:</strong> IndexedDB (Dexie.js)</p>
                <p><strong className="text-slate-400">Cache Clima:</strong> 30min TTL</p>
                <p><strong className="text-slate-400">Cache Elevação:</strong> Permanente</p>
                <p><strong className="text-slate-400">Cache Incidentes:</strong> 5min TTL</p>
                <p><strong className="text-slate-400">Supabase:</strong> Substituir saveRoute() em db.ts</p>
              </div>
            </div>
          </div>
        </div>

        {/* Botão Salvar */}
        <button
          onClick={handleSave}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#0B3D2E] text-white font-bold text-base hover:shadow-[0_0_30px_rgba(0,212,170,0.3)] hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
        >
          <Save size={18} />
          Salvar Configurações
        </button>
      </div>
    </div>
  );
}
