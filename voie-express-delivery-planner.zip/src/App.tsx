import { useAppStore } from './store/appStore';
import { StatusBar, BottomNav } from './components/shared/StatusBar';
import { Toast } from './components/shared/Toast';
import { HomeScreen } from './components/HomeScreen';
import { LoadingScreen } from './components/LoadingScreen';
import { RouteScreen } from './components/RouteScreen';
import { NavigateScreen } from './components/NavigateScreen';
import { DashboardScreen } from './components/DashboardScreen';
import { SettingsScreen } from './components/SettingsScreen';

export default function App() {
  const store = useAppStore();
  const { screen, toast, showToast, isOnline, navigate, loadingProgress } = store;

  return (
    <div className="min-h-screen bg-[#0F172A] text-slate-100">
      {screen !== 'navigate' && (
        <StatusBar isOnline={isOnline} screen={screen} onNavigate={navigate} />
      )}

      {isOnline && (
        <div className="fixed top-[52px] left-0 right-0 z-40 overflow-hidden h-0.5 opacity-40">
          <div className="sync-bar" />
        </div>
      )}

      <main className="relative">
        {screen === 'home' && (
          <div className="animate-fade-in">
            <HomeScreen store={store} />
          </div>
        )}
        {screen === 'loading' && (
          <div className="animate-fade-in">
            <LoadingScreen
              step={loadingProgress.step}
              total={loadingProgress.total}
              message={loadingProgress.message}
            />
          </div>
        )}
        {screen === 'route' && (
          <div className="animate-fade-in" style={{ height: 'calc(100vh - 52px)' }}>
            <RouteScreen store={store} />
          </div>
        )}
        {screen === 'navigate' && (
          <div className="animate-fade-in" style={{ height: '100vh' }}>
            <NavigateScreen store={store} />
          </div>
        )}
        {screen === 'dashboard' && (
          <div className="animate-fade-in">
            <DashboardScreen store={store} />
          </div>
        )}
        {screen === 'settings' && (
          <div className="animate-fade-in">
            <SettingsScreen store={store} />
          </div>
        )}
      </main>

      {screen !== 'navigate' && (
        <BottomNav screen={screen} onNavigate={navigate} />
      )}

      {toast && toast.message && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => showToast('', 'info')}
        />
      )}
    </div>
  );
}
