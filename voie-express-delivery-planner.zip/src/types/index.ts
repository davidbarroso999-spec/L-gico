// ═══════════════════════════════════════════════════════════════
// TIPOS GLOBAIS — Voie Express
// Define todas as interfaces usadas no sistema
// ═══════════════════════════════════════════════════════════════

export type VehicleType = 'car' | 'motorcycle' | 'truck' | 'van' | 'boat';
export type Priority = 'fastest' | 'shortest' | 'economic' | 'safest' | 'balanced';
export type RouteStatus = 'pending' | 'in_progress' | 'completed' | 'failed';
export type IncidentType = 'accident' | 'road_closed' | 'construction' | 'congestion' | 'flood' | 'pothole' | 'other';
export type WeatherMain = 'Rain' | 'Thunderstorm' | 'Clouds' | 'Clear' | 'Drizzle' | 'Snow' | 'Mist' | 'Fog';
export type Screen = 'home' | 'loading' | 'route' | 'navigate' | 'dashboard' | 'settings';

// Coordenada geográfica
export interface Coordinate {
  lat: number;
  lon: number;
}

// Endereço de entrega
export interface DeliveryStop {
  id: string;
  address: string;
  coordinate?: Coordinate;
  timeWindow?: { start: string; end: string }; // ex: "08:00", "12:00"
  notes?: string;
  status: 'pending' | 'delivered' | 'failed';
  deliveredAt?: string;
  photo?: string;
  failureReason?: string;
}

// Dados climáticos
export interface WeatherData {
  temp: number;
  feelsLike: number;
  humidity: number;
  main: WeatherMain;
  description: string;
  windSpeed: number;
  visibility: number;
  rainMmPerHour: number;
  icon: string;
}

// Dados de elevação
export interface ElevationData {
  elevation: number; // metros acima do nível do mar
  slope?: number;    // inclinação percentual calculada
}

// Incidente de trânsito
export interface TrafficIncident {
  type: IncidentType;
  severity: number; // 1-4
  lat: number;
  lon: number;
  description: string;
  roadClosed: boolean;
}

// Trecho da rota entre duas paradas
export interface RouteLeg {
  fromStop: DeliveryStop;
  toStop: DeliveryStop;
  distanceKm: number;
  durationMin: number;
  weather?: WeatherData;
  elevationGain?: number;
  elevationLoss?: number;
  incidents?: TrafficIncident[];
  riskScore: number;      // 0-100
  riskFactors: string[];  // ex: ['Chuva forte', 'Incidente TomTom']
  fuelFactor: number;     // multiplicador de consumo (1.0 = normal)
  polyline?: [number, number][]; // coordenadas para desenhar no mapa
  color: 'green' | 'yellow' | 'red'; // cor do trecho
}

// Rota completa calculada
export interface CalculatedRoute {
  id: string;
  createdAt: string;
  stops: DeliveryStop[];
  legs: RouteLeg[];
  totalDistanceKm: number;
  totalDurationMin: number;
  estimatedFuelLiters: number;
  score: number; // 0-100
  alertCount: number;
  priority: Priority;
  vehicle: VehicleType;
  seasonalBadge?: string; // ex: "Época de Cheias Ativa"
  status: RouteStatus;
}

// Ocorrência reportada pelo motorista
export interface Occurrence {
  id: string;
  type: IncidentType;
  lat: number;
  lon: number;
  description: string;
  photo?: string; // base64 comprimido
  timestamp: string;
  synced: boolean;
  expiresAt: string; // +24h
}

// Configurações do usuário
export interface UserSettings {
  orsKey: string;
  openweatherKey: string;
  visualcrossingKey: string;
  tomtomKey: string;
  defaultPriority: Priority;
  defaultVehicle: VehicleType;
  avoidDirt: boolean;
  avoidFlood: boolean;
  avoidSlopes: boolean;
  avoidNoSignal: boolean;
  preferAsphalt: boolean;
  darkMode: boolean;
  offlineMode: boolean;
}

// Pesos de otimização por prioridade
export interface OptimizationWeights {
  distance: number;  // w1
  time: number;      // w2
  fuel: number;      // w3
  risk: number;      // w4
}

// KPI para o dashboard
export interface DashboardKPI {
  totalKm: number;
  totalDeliveries: number;
  avgTimeMin: number;
  totalOccurrences: number;
  onTimeRate: number; // percentual
}

// Item do histórico de rotas
export interface RouteHistory {
  id: string;
  date: string;
  addresses: string[];
  score: number;
  totalKm: number;
  deliveries: number;
  status: RouteStatus;
}
