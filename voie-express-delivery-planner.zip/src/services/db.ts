// ═══════════════════════════════════════════════════════════════
// BANCO LOCAL — IndexedDB com Dexie.js
// Armazena rotas, ocorrências e cache de dados de API
// Substitua por Supabase para persistência em nuvem
// ═══════════════════════════════════════════════════════════════

import Dexie, { type Table } from 'dexie';
import type { CalculatedRoute, Occurrence, RouteHistory } from '../types';

// Tipos de cache
interface CacheWeather {
  key: string;      // "{lat2d},{lon2d}"
  data: object;
  expiresAt: number;
}

interface CacheElevation {
  key: string;      // "{lat2d},{lon2d}"
  elevation: number;
  expiresAt: number;
}

interface CacheIncidents {
  key: string;      // hash do bbox
  data: object[];
  expiresAt: number;
}

// ── Classe do banco ──────────────────────────────────────────────
class VoieExpressDB extends Dexie {
  rotas!: Table<CalculatedRoute, string>;
  ocorrencias!: Table<Occurrence, string>;
  historico!: Table<RouteHistory, string>;
  cacheClima!: Table<CacheWeather, string>;
  cacheElevacao!: Table<CacheElevation, string>;
  cacheIncidentes!: Table<CacheIncidents, string>;

  constructor() {
    super('VoieExpressDB');

    this.version(1).stores({
      rotas: 'id, createdAt, status',
      ocorrencias: 'id, type, timestamp, synced',
      historico: 'id, date, status',
      cacheClima: 'key, expiresAt',
      cacheElevacao: 'key, expiresAt',
      cacheIncidentes: 'key, expiresAt',
    });
  }
}

export const db = new VoieExpressDB();

// ── Helpers de cache ─────────────────────────────────────────────

/** Salva dados climáticos no cache */
export async function setCachedWeather(lat: number, lon: number, data: object, ttlMs: number) {
  const key = `${lat.toFixed(2)},${lon.toFixed(2)}`;
  await db.cacheClima.put({ key, data, expiresAt: Date.now() + ttlMs });
}

/** Recupera dados climáticos do cache */
export async function getCachedWeather(lat: number, lon: number) {
  const key = `${lat.toFixed(2)},${lon.toFixed(2)}`;
  const record = await db.cacheClima.get(key);
  if (!record || record.expiresAt < Date.now()) return null;
  return record.data;
}

/** Salva elevação no cache (permanente) */
export async function setCachedElevation(lat: number, lon: number, elevation: number) {
  const key = `${lat.toFixed(3)},${lon.toFixed(3)}`;
  await db.cacheElevacao.put({ key, elevation, expiresAt: Date.now() + 365 * 24 * 3600 * 1000 });
}

/** Recupera elevação do cache */
export async function getCachedElevation(lat: number, lon: number): Promise<number | null> {
  const key = `${lat.toFixed(3)},${lon.toFixed(3)}`;
  const record = await db.cacheElevacao.get(key);
  if (!record) return null;
  return record.elevation;
}

/** Salva incidentes no cache */
export async function setCachedIncidents(bboxHash: string, data: object[], ttlMs: number) {
  await db.cacheIncidentes.put({ key: bboxHash, data, expiresAt: Date.now() + ttlMs });
}

/** Recupera incidentes do cache */
export async function getCachedIncidents(bboxHash: string) {
  const record = await db.cacheIncidentes.get(bboxHash);
  if (!record || record.expiresAt < Date.now()) return null;
  return record.data;
}

/** Salva rota calculada */
export async function saveRoute(route: CalculatedRoute) {
  await db.rotas.put(route);
}

/** Recupera rota por ID */
export async function getRoute(id: string) {
  return db.rotas.get(id);
}

/** Lista rotas recentes */
export async function listRoutes(limit = 20) {
  return db.rotas.orderBy('createdAt').reverse().limit(limit).toArray();
}

/** Salva ocorrência local */
export async function saveOccurrence(occurrence: Occurrence) {
  await db.ocorrencias.put(occurrence);
}

/** Lista ocorrências não sincronizadas */
export async function getPendingOccurrences() {
  return db.ocorrencias.where('synced').equals(0).toArray();
}

/** Limpa dados expirados */
export async function cleanExpiredCache() {
  const now = Date.now();
  await db.cacheClima.where('expiresAt').below(now).delete();
  await db.cacheIncidentes.where('expiresAt').below(now).delete();
}
