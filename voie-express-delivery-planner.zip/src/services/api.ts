// ═══════════════════════════════════════════════════════════════
// SERVIÇOS DE API — Voie Express
// Cada função tem try/catch + fallback mock para resiliência
// ═══════════════════════════════════════════════════════════════

import { API_URLS, MOCK_ADDRESSES, CACHE_TTL } from '../constants';
import { getCachedWeather, setCachedWeather, getCachedElevation, setCachedElevation } from './db';
import type { WeatherData, TrafficIncident, Coordinate } from '../types';

// ── Retorna chaves salvas no localStorage (ou padrão) ───────────
function getKeys() {
  try {
    const s = localStorage.getItem('voie_settings');
    if (s) return JSON.parse(s);
  } catch {}
  return {
    orsKey: 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6ImE2MGFmMzA2YmQ5NzQ4MjQ4ODljOGNhMTgzM2Y3YjAwIiwiaCI6Im11cm11cjY0In0=',
    openweatherKey: 'a46d5eac976d211d6bde3bbaf70073f9',
    visualcrossingKey: 'VBC92VXW9WTHYTJMUYGSBWX78',
    tomtomKey: 'RTvaCPgTDMD4fSaOTbGkZNdHnnFs7Q4K',
  };
}

// ── GEOCODIFICAÇÃO ───────────────────────────────────────────────

/** Geocodifica um endereço para coordenadas (Nominatim + ORS fallback) */
export async function geocodeAddress(address: string): Promise<Coordinate | null> {
  // Verifica se é um dos endereços mock
  const mock = MOCK_ADDRESSES.find(m => m.address.toLowerCase().includes(address.toLowerCase().slice(0, 20)));
  if (mock) return { lat: mock.lat, lon: mock.lon };

  try {
    // Tenta Nominatim primeiro (gratuito, sem chave)
    const url = `${API_URLS.NOMINATIM}/search?format=json&q=${encodeURIComponent(address)}&limit=1&countrycodes=br`;
    const resp = await fetch(url, { headers: { 'Accept-Language': 'pt-BR' } });
    if (!resp.ok) throw new Error(`Nominatim ${resp.status}`);
    const data = await resp.json();
    if (data.length > 0) {
      return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) };
    }
  } catch (e) {
    console.warn('[Geocode] Nominatim falhou, tentando ORS:', e);
  }

  try {
    // Fallback: ORS Geocode
    const { orsKey } = getKeys();
    const url = `${API_URLS.ORS_BASE}/geocode/search?api_key=${orsKey}&text=${encodeURIComponent(address)}&size=1`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`ORS Geocode ${resp.status}`);
    const data = await resp.json();
    if (data.features?.length > 0) {
      const [lon, lat] = data.features[0].geometry.coordinates;
      return { lat, lon };
    }
  } catch (e) {
    console.warn('[Geocode] ORS falhou:', e);
  }

  // Mock aleatório próximo a Manaus
  console.warn('[Geocode] Usando coordenada mock para:', address);
  return {
    lat: -3.1 + (Math.random() - 0.5) * 0.1,
    lon: -60.0 + (Math.random() - 0.5) * 0.1,
  };
}

// ── ORS DIRECTIONS ───────────────────────────────────────────────

/** Calcula direções entre dois pontos via ORS */
export async function getDirections(
  from: Coordinate,
  to: Coordinate,
  profile = 'driving-car'
): Promise<{ distanceKm: number; durationMin: number; polyline: [number, number][] }> {
  try {
    const { orsKey } = getKeys();
    const url = `${API_URLS.ORS_BASE}/directions/${profile}`;
    const body = {
      coordinates: [[from.lon, from.lat], [to.lon, to.lat]],
      instructions: false,
      geometry: true,
    };
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Authorization': orsKey, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!resp.ok) throw new Error(`ORS Directions ${resp.status}`);
    const data = await resp.json();
    const route = data.routes[0];
    const distanceKm = route.summary.distance / 1000;
    const durationMin = route.summary.duration / 60;

    // Decodifica polyline (formato Google/ORS)
    const polyline = decodePolyline(route.geometry);
    return { distanceKm, durationMin, polyline };
  } catch (e) {
    console.warn('[ORS Directions] Usando mock:', e);
    // Mock: linha reta + distância euclidiana aproximada
    const distanceKm = haversineKm(from, to) * 1.3; // +30% tortuosidade
    const durationMin = distanceKm * 2.5; // ~24 km/h urbano
    const polyline: [number, number][] = [
      [from.lat, from.lon],
      [(from.lat + to.lat) / 2 + 0.002, (from.lon + to.lon) / 2],
      [to.lat, to.lon],
    ];
    return { distanceKm, durationMin, polyline };
  }
}

/** Calcula matriz de distâncias entre múltiplos pontos via ORS */
export async function getDistanceMatrix(
  points: Coordinate[],
  profile = 'driving-car'
): Promise<number[][]> {
  try {
    const { orsKey } = getKeys();
    const url = `${API_URLS.ORS_BASE}/matrix/${profile}`;
    const coordinates = points.map(p => [p.lon, p.lat]);
    const body = { locations: coordinates, metrics: ['duration', 'distance'], units: 'km' };
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Authorization': orsKey, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!resp.ok) throw new Error(`ORS Matrix ${resp.status}`);
    const data = await resp.json();
    return data.durations; // matriz de tempos em segundos
  } catch (e) {
    console.warn('[ORS Matrix] Usando mock Haversine:', e);
    // Mock: matriz de distâncias Haversine em minutos
    const n = points.length;
    return Array.from({ length: n }, (_, i) =>
      Array.from({ length: n }, (_, j) =>
        i === j ? 0 : haversineKm(points[i], points[j]) * 2.5
      )
    );
  }
}

// ── CLIMA ─────────────────────────────────────────────────────────

/** Busca clima atual (com cache de 30min) */
export async function getCurrentWeather(lat: number, lon: number): Promise<WeatherData> {
  // Verifica cache
  const cached = await getCachedWeather(lat, lon);
  if (cached) return cached as WeatherData;

  try {
    const { openweatherKey } = getKeys();
    const url = `${API_URLS.OPENWEATHER_BASE}/weather?lat=${lat}&lon=${lon}&appid=${openweatherKey}&units=metric&lang=pt_br`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`OpenWeather ${resp.status}`);
    const d = await resp.json();
    const weather: WeatherData = {
      temp: d.main.temp,
      feelsLike: d.main.feels_like,
      humidity: d.main.humidity,
      main: d.weather[0].main,
      description: d.weather[0].description,
      windSpeed: d.wind.speed,
      visibility: d.visibility || 10000,
      rainMmPerHour: d.rain?.['1h'] ?? 0,
      icon: d.weather[0].icon,
    };
    await setCachedWeather(lat, lon, weather, CACHE_TTL.WEATHER);
    return weather;
  } catch (e) {
    console.warn('[OpenWeather] Usando mock:', e);
    return getMockWeather(lat, lon);
  }
}

/** Gera dados climáticos mock baseados na época do ano em Manaus */
function getMockWeather(_lat: number, _lon: number): WeatherData {
  const month = new Date().getMonth(); // 0=Jan
  // Manaus: cheia dez-mai, seca jun-nov
  const isRainy = month >= 11 || month <= 4;
  const isThunder = isRainy && Math.random() > 0.7;
  const rainMm = isRainy ? 2 + Math.random() * 8 : 0;

  return {
    temp: isRainy ? 27 + Math.random() * 4 : 32 + Math.random() * 5,
    feelsLike: isRainy ? 33 : 38,
    humidity: isRainy ? 85 + Math.random() * 10 : 55 + Math.random() * 15,
    main: isThunder ? 'Thunderstorm' : isRainy && rainMm > 2 ? 'Rain' : 'Clouds',
    description: isThunder ? 'Tempestade com raios' : isRainy ? 'Chuva moderada' : 'Parcialmente nublado',
    windSpeed: 3 + Math.random() * 5,
    visibility: isThunder ? 2000 : isRainy ? 5000 : 10000,
    rainMmPerHour: rainMm,
    icon: isThunder ? '11d' : isRainy ? '10d' : '03d',
  };
}

// ── ELEVAÇÃO ──────────────────────────────────────────────────────

/** Busca elevação de uma coordenada (com cache permanente) */
export async function getElevation(lat: number, lon: number): Promise<number> {
  const cached = await getCachedElevation(lat, lon);
  if (cached !== null) return cached;

  try {
    const url = `${API_URLS.OPENTOPODATA_BASE}/srtm30m?locations=${lat},${lon}`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`OpenTopoData ${resp.status}`);
    const data = await resp.json();
    const elevation = data.results[0].elevation;
    await setCachedElevation(lat, lon, elevation);
    return elevation;
  } catch (e) {
    console.warn('[OpenTopoData] Usando mock:', e);
    // Mock: Manaus tem elevação ~60m com pequenas variações
    const mockElevation = 35 + Math.abs(lat + 3.1) * 200 + Math.random() * 20;
    await setCachedElevation(lat, lon, mockElevation);
    return mockElevation;
  }
}

/** Busca elevações de múltiplos pontos em batch */
export async function getElevationBatch(points: Coordinate[]): Promise<number[]> {
  try {
    const locStr = points.map(p => `${p.lat},${p.lon}`).join('|');
    const url = `${API_URLS.OPENTOPODATA_BASE}/srtm30m?locations=${locStr}`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`OpenTopoData batch ${resp.status}`);
    const data = await resp.json();
    return data.results.map((r: { elevation: number }) => r.elevation);
  } catch (e) {
    console.warn('[OpenTopoData Batch] Usando mock:', e);
    return points.map((p) => 35 + Math.abs(p.lat + 3.1) * 200 + Math.random() * 20);
  }
}

// ── INCIDENTES TOMTOM ─────────────────────────────────────────────

/** Busca incidentes de trânsito em uma área via TomTom */
export async function getTrafficIncidents(
  minLat: number, minLon: number, maxLat: number, maxLon: number
): Promise<TrafficIncident[]> {
  try {
    const { tomtomKey } = getKeys();
    const bbox = `${minLon},${minLat},${maxLon},${maxLat}`;
    const url = `${API_URLS.TOMTOM_BASE}/4/incidentDetails/s3/${bbox}/10/pt-BR.json?key=${tomtomKey}`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`TomTom ${resp.status}`);
    const data = await resp.json();
    return (data.incidents || []).map((inc: {
      type: number;
      properties?: { iconCategory?: number; description?: string };
      geometry?: { coordinates?: number[][] };
    }) => ({
      type: mapTomTomType(inc.type),
      severity: inc.properties?.iconCategory ?? 1,
      lat: inc.geometry?.coordinates?.[1] ?? (minLat + maxLat) / 2,
      lon: inc.geometry?.coordinates?.[0] ?? (minLon + maxLon) / 2,
      description: inc.properties?.description ?? 'Incidente reportado',
      roadClosed: inc.type === 6,
    }));
  } catch (e) {
    console.warn('[TomTom] Usando mock:', e);
    return getMockIncidents(minLat, minLon, maxLat, maxLon);
  }
}

/** Mapeia tipo TomTom para tipo interno */
function mapTomTomType(type: number): TrafficIncident['type'] {
  const map: Record<number, TrafficIncident['type']> = {
    1: 'accident', 2: 'congestion', 3: 'construction', 6: 'road_closed',
  };
  return map[type] ?? 'other';
}

/** Gera incidentes mock aleatórios na área */
function getMockIncidents(minLat: number, minLon: number, maxLat: number, maxLon: number): TrafficIncident[] {
  const incidents: TrafficIncident[] = [];
  const numIncidents = Math.floor(Math.random() * 3); // 0-2 incidentes
  const types: TrafficIncident['type'][] = ['congestion', 'construction', 'accident'];

  for (let i = 0; i < numIncidents; i++) {
    incidents.push({
      type: types[Math.floor(Math.random() * types.length)],
      severity: Math.ceil(Math.random() * 3),
      lat: minLat + Math.random() * (maxLat - minLat),
      lon: minLon + Math.random() * (maxLon - minLon),
      description: ['Congestionamento na via', 'Obras na pista', 'Acidente reportado'][i % 3],
      roadClosed: false,
    });
  }
  return incidents;
}

// ── DADOS SAZONAIS (Visual Crossing) ─────────────────────────────

/** Busca perfil sazonal do mês atual para uma localidade */
export async function getSeasonalProfile(lat: number, lon: number): Promise<{
  avgPrecipMm: number;
  rainyDays: number;
  season: 'cheia' | 'seca' | 'transição';
  badge: string;
}> {
  const month = new Date().getMonth();

  try {
    const { visualcrossingKey } = getKeys();
    const location = `${lat},${lon}`;
    const url = `${API_URLS.VISUALCROSSING_BASE}/timeline/${location}?unitGroup=metric&key=${visualcrossingKey}&lang=pt&include=days&elements=precip,precipdays,humidity`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`VisualCrossing ${resp.status}`);
    const data = await resp.json();
    const days = data.days?.slice(0, 30) ?? [];
    const avgPrecipMm = days.reduce((s: number, d: { precip?: number }) => s + (d.precip || 0), 0) / (days.length || 1);
    const rainyDays = days.filter((d: { precip?: number }) => (d.precip || 0) > 1).length;
    return buildSeasonProfile(month, avgPrecipMm, rainyDays);
  } catch (e) {
    console.warn('[VisualCrossing] Usando mock sazonal:', e);
    // Mock baseado no calendário climático de Manaus
    const avgPrecipMm = [280, 290, 320, 280, 250, 80, 55, 50, 70, 110, 150, 230][month];
    const rainyDays = [22, 20, 22, 18, 15, 8, 6, 6, 8, 12, 15, 19][month];
    return buildSeasonProfile(month, avgPrecipMm, rainyDays);
  }
}

function buildSeasonProfile(month: number, avgPrecipMm: number, rainyDays: number) {
  // Manaus: cheia dez-mai, seca jun-set, transição out-nov
  const season: 'cheia' | 'seca' | 'transição' =
    (month >= 11 || month <= 4) ? 'cheia' :
    (month >= 5 && month <= 8) ? 'seca' : 'transição';

  const badge =
    season === 'cheia' ? '🌊 Período de Cheias Ativo' :
    season === 'seca' ? '☀️ Período de Seca' :
    '🌦️ Período de Transição';

  return { avgPrecipMm, rainyDays, season, badge };
}

// ── UTILIDADES MATEMÁTICAS ────────────────────────────────────────

/** Distância Haversine em km entre dois pontos */
export function haversineKm(a: Coordinate, b: Coordinate): number {
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const x = Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function toRad(deg: number) { return deg * Math.PI / 180; }

/** Decodifica polyline codificado em base64/Google format */
export function decodePolyline(encoded: string): [number, number][] {
  // ORS retorna GeoJSON diretamente quando geometry: true
  // Se for string, decodifica formato Google
  if (typeof encoded !== 'string') return [];
  const points: [number, number][] = [];
  let index = 0, lat = 0, lng = 0;
  while (index < encoded.length) {
    let result = 1, shift = 0, b: number;
    do {
      b = encoded.charCodeAt(index++) - 63 - 1;
      result += b << shift;
      shift += 5;
    } while (b >= 0x1f);
    lat += (result & 1) !== 0 ? ~(result >> 1) : result >> 1;
    result = 1; shift = 0;
    do {
      b = encoded.charCodeAt(index++) - 63 - 1;
      result += b << shift;
      shift += 5;
    } while (b >= 0x1f);
    lng += (result & 1) !== 0 ? ~(result >> 1) : result >> 1;
    points.push([lat * 1e-5, lng * 1e-5]);
  }
  return points;
}

/** Calcula inclinação percentual entre dois pontos */
export function calculateSlope(fromElevation: number, toElevation: number, distanceKm: number): number {
  if (distanceKm === 0) return 0;
  return ((toElevation - fromElevation) / (distanceKm * 1000)) * 100;
}
