// ═══════════════════════════════════════════════════════════════
// MOTOR DE ROTAS — VRP Simplificado com Função de Custo
// Calcula a sequência ótima de entregas considerando:
// distância, tempo, consumo e risco (clima, elevação, incidentes)
// ═══════════════════════════════════════════════════════════════

import { PRIORITY_WEIGHTS, RISK_PENALTIES, FUEL_CONSUMPTION, VEHICLE_ORS_PROFILE } from '../constants';
import {
  geocodeAddress, getDirections, getDistanceMatrix,
  getCurrentWeather, getElevationBatch, getTrafficIncidents,
  getSeasonalProfile, calculateSlope
} from './api';
import type {
  DeliveryStop, CalculatedRoute, RouteLeg, Priority,
  VehicleType, WeatherData, TrafficIncident, Coordinate
} from '../types';

// ── FUNÇÃO PRINCIPAL ─────────────────────────────────────────────

/** Calcula a rota completa otimizada */
export async function calculateOptimalRoute(
  addresses: string[],
  priority: Priority,
  vehicle: VehicleType,
  options: {
    avoidDirt?: boolean;
    avoidFlood?: boolean;
    avoidSlopes?: boolean;
    avoidNoSignal?: boolean;
    preferAsphalt?: boolean;
  } = {},
  onProgress?: (step: number, total: number, message: string) => void
): Promise<CalculatedRoute> {
  const steps = 9;
  let step = 0;
  const progress = (msg: string) => onProgress?.(++step, steps, msg);

  // ── ETAPA 1: Geocodificar endereços ──────────────────────────
  progress('Geocodificando endereços...');
  const stops: DeliveryStop[] = await Promise.all(
    addresses.map(async (address, i) => {
      const coord = await geocodeAddress(address);
      return {
        id: `stop-${i}-${Date.now()}`,
        address,
        coordinate: coord ?? undefined,
        status: 'pending' as const,
      };
    })
  );

  // Filtra paradas sem coordenada
  const validStops = stops.filter(s => s.coordinate);

  if (validStops.length < 2) {
    throw new Error('São necessários pelo menos 2 endereços válidos.');
  }

  // ── ETAPA 2: Calcular matriz de distâncias ───────────────────
  progress('Calculando matriz de distâncias...');
  const coords = validStops.map(s => s.coordinate!);
  const profile = VEHICLE_ORS_PROFILE[vehicle] ?? 'driving-car';
  const timeMatrix = await getDistanceMatrix(coords, profile);

  // ── ETAPA 3: Analisar clima ──────────────────────────────────
  progress('Analisando condições climáticas...');
  const weatherData = await Promise.all(
    coords.map(c => getCurrentWeather(c.lat, c.lon))
  );

  // ── ETAPA 4: Buscar elevação ─────────────────────────────────
  progress('Verificando elevação e relevo...');
  const elevations = await getElevationBatch(coords);

  // ── ETAPA 5: Buscar incidentes ───────────────────────────────
  progress('Consultando incidentes de trânsito...');
  const allLats = coords.map(c => c.lat);
  const allLons = coords.map(c => c.lon);
  const bbox = {
    minLat: Math.min(...allLats) - 0.05,
    maxLat: Math.max(...allLats) + 0.05,
    minLon: Math.min(...allLons) - 0.05,
    maxLon: Math.max(...allLons) + 0.05,
  };
  const incidents = await getTrafficIncidents(bbox.minLat, bbox.minLon, bbox.maxLat, bbox.maxLon);

  // ── ETAPA 6: Perfil sazonal ──────────────────────────────────
  progress('Aplicando perfil sazonal...');
  const centerLat = coords.reduce((s, c) => s + c.lat, 0) / coords.length;
  const centerLon = coords.reduce((s, c) => s + c.lon, 0) / coords.length;
  const seasonal = await getSeasonalProfile(centerLat, centerLon);

  // ── ETAPA 7: Algoritmo guloso de sequenciamento ──────────────
  progress('Otimizando sequência de entregas...');
  const weights = PRIORITY_WEIGHTS[priority];
  const sequencedIndices = greedyVRP(timeMatrix, weatherData, elevations, incidents, weights, seasonal, options);
  const sequencedStops = sequencedIndices.map(i => validStops[i]);

  // ── ETAPA 8: Calcular trechos detalhados ─────────────────────
  progress('Calculando score de risco por trecho...');
  const legs: RouteLeg[] = [];
  for (let i = 0; i < sequencedStops.length - 1; i++) {
    const fromIdx = sequencedIndices[i];
    const toIdx = sequencedIndices[i + 1];
    const from = sequencedStops[i];
    const to = sequencedStops[i + 1];

    // Busca direções reais
    const directions = await getDirections(from.coordinate!, to.coordinate!, profile);

    // Calcula risco do trecho
    const legWeather = weatherData[toIdx];
    const elevGain = Math.max(0, elevations[toIdx] - elevations[fromIdx]);
    const elevLoss = Math.max(0, elevations[fromIdx] - elevations[toIdx]);
    const slope = calculateSlope(elevations[fromIdx], elevations[toIdx], directions.distanceKm);

    // Filtra incidentes próximos ao trecho
    const legIncidents = filterIncidentsNearLeg(incidents, from.coordinate!, to.coordinate!);

    const { riskScore, riskFactors } = calculateRiskScore(
      legWeather, slope, legIncidents, seasonal, options, vehicle
    );

    // Fator de consumo de combustível baseado em elevação
    const fuelFactor = 1.0 + (elevGain > 20 ? 0.2 : 0) - (elevLoss > 20 ? 0.1 : 0);

    const color: RouteLeg['color'] = riskScore > 60 ? 'red' : riskScore > 30 ? 'yellow' : 'green';

    legs.push({
      fromStop: from,
      toStop: to,
      distanceKm: directions.distanceKm,
      durationMin: directions.durationMin,
      weather: legWeather,
      elevationGain: elevGain,
      elevationLoss: elevLoss,
      incidents: legIncidents,
      riskScore,
      riskFactors,
      fuelFactor,
      polyline: directions.polyline,
      color,
    });
  }

  // ── ETAPA 9: Montar resultado final ──────────────────────────
  progress('Preparando visualização da rota...');
  const totalDistanceKm = legs.reduce((s, l) => s + l.distanceKm, 0);
  const totalDurationMin = legs.reduce((s, l) => s + l.durationMin, 0);
  const kmPerLiter = FUEL_CONSUMPTION[vehicle] ?? 10;
  const fuelFactor = legs.reduce((s, l) => s + l.fuelFactor, 0) / legs.length;
  const estimatedFuelLiters = (totalDistanceKm / kmPerLiter) * fuelFactor;
  const avgRisk = legs.reduce((s, l) => s + l.riskScore, 0) / legs.length;
  const score = Math.round(Math.max(0, Math.min(100, 100 - avgRisk)));
  const alertCount = legs.filter(l => l.riskScore > 30).length;

  const route: CalculatedRoute = {
    id: `route-${Date.now()}`,
    createdAt: new Date().toISOString(),
    stops: sequencedStops,
    legs,
    totalDistanceKm,
    totalDurationMin,
    estimatedFuelLiters,
    score,
    alertCount,
    priority,
    vehicle,
    seasonalBadge: seasonal.season !== 'seca' ? seasonal.badge : undefined,
    status: 'pending',
  };

  return route;
}

// ── ALGORITMO GULOSO VRP ──────────────────────────────────────────

/** Sequencia paradas com algoritmo guloso ponderado */
function greedyVRP(
  timeMatrix: number[][],
  weatherData: WeatherData[],
  elevations: number[],
  incidents: TrafficIncident[],
  weights: { distance: number; time: number; fuel: number; risk: number },
  seasonal: { season: 'cheia' | 'seca' | 'transição'; avgPrecipMm: number },
  options: Record<string, boolean | undefined>
): number[] {
  const n = timeMatrix.length;
  const visited = new Set<number>();
  const sequence: number[] = [0]; // começa sempre da primeira parada (origem)
  visited.add(0);

  while (sequence.length < n) {
    const current = sequence[sequence.length - 1];
    let bestNext = -1;
    let bestCost = Infinity;

    for (let j = 0; j < n; j++) {
      if (visited.has(j)) continue;

      // Tempo normalizado (0-1)
      const timeNorm = (timeMatrix[current][j] ?? 999) / 60;

      // Distância aproximada (Haversine em km, normalizada)
      const distNorm = timeNorm * 0.4; // proxy baseado em tempo

      // Consumo estimado
      const fuelNorm = distNorm;

      // Risco do destino
      const weather = weatherData[j];
      const riskScore = quickRisk(weather, elevations[current], elevations[j], distNorm, incidents, seasonal, options);
      const riskNorm = riskScore / 100;

      const cost = weights.distance * distNorm +
                   weights.time * timeNorm +
                   weights.fuel * fuelNorm +
                   weights.risk * riskNorm;

      if (cost < bestCost) {
        bestCost = cost;
        bestNext = j;
      }
    }

    if (bestNext === -1) break;
    sequence.push(bestNext);
    visited.add(bestNext);
  }

  return sequence;
}

/** Calcula risco rápido para o algoritmo guloso */
function quickRisk(
  weather: WeatherData,
  fromElev: number,
  toElev: number,
  distKm: number,
  _incidents: TrafficIncident[],
  seasonal: { season: 'cheia' | 'seca' | 'transição'; avgPrecipMm: number },
  _options: Record<string, boolean | undefined>
): number {
  let risk = 0;
  if (weather.main === 'Thunderstorm') risk += RISK_PENALTIES.THUNDERSTORM;
  else if (weather.rainMmPerHour > 5) risk += RISK_PENALTIES.HEAVY_RAIN;
  if (seasonal.season === 'cheia') risk += RISK_PENALTIES.FLOOD_HISTORY;
  const slope = distKm > 0 ? Math.abs(toElev - fromElev) / (distKm * 1000) * 100 : 0;
  if (slope > 10) risk += RISK_PENALTIES.STEEP_SLOPE;
  return Math.min(100, risk);
}

// ── CÁLCULO DE RISCO POR TRECHO ───────────────────────────────────

/** Calcula score e fatores de risco para um trecho */
function calculateRiskScore(
  weather: WeatherData,
  slope: number,
  incidents: TrafficIncident[],
  seasonal: { season: 'cheia' | 'seca' | 'transição'; avgPrecipMm: number },
  options: { avoidDirt?: boolean; avoidFlood?: boolean; avoidSlopes?: boolean; avoidNoSignal?: boolean },
  vehicle: VehicleType
): { riskScore: number; riskFactors: string[] } {
  let risk = 0;
  const factors: string[] = [];

  // Clima
  if (weather.main === 'Thunderstorm') {
    risk += RISK_PENALTIES.THUNDERSTORM;
    factors.push(`⛈️ Tempestade (+${RISK_PENALTIES.THUNDERSTORM}%)`);
  } else if (weather.rainMmPerHour > 5) {
    risk += RISK_PENALTIES.HEAVY_RAIN;
    factors.push(`🌧️ Chuva forte (${weather.rainMmPerHour.toFixed(1)}mm/h, +${RISK_PENALTIES.HEAVY_RAIN}%)`);
  } else if (weather.main === 'Rain') {
    risk += 8;
    factors.push(`🌦️ Chuva leve (+8%)`);
  }

  // Sazonalidade
  if (seasonal.season === 'cheia') {
    risk += RISK_PENALTIES.FLOOD_HISTORY;
    factors.push(`🌊 Período de cheias (+${RISK_PENALTIES.FLOOD_HISTORY}%)`);
  } else if (seasonal.season === 'seca' && options.avoidDirt) {
    risk += 5;
    factors.push(`🌵 Período de seca — ramais de terra (+5%)`);
  }

  // Incidentes TomTom
  if (incidents.length > 0) {
    const hasClosed = incidents.some(i => i.roadClosed);
    if (hasClosed) {
      risk += 40;
      factors.push(`🚫 Via interditada (+40%)`);
    } else {
      risk += RISK_PENALTIES.TOMTOM_INCIDENT;
      factors.push(`⚠️ ${incidents.length} incidente(s) no trecho (+${RISK_PENALTIES.TOMTOM_INCIDENT}%)`);
    }
  }

  // Elevação / Ladeira
  const absSlope = Math.abs(slope);
  if (absSlope > 15 && vehicle === 'truck') {
    risk += 25;
    factors.push(`⛰️ Ladeira íngreme para caminhão (${absSlope.toFixed(1)}%, +25%)`);
  } else if (absSlope > 10) {
    risk += RISK_PENALTIES.STEEP_SLOPE;
    factors.push(`🏔️ Relevo acentuado (${absSlope.toFixed(1)}%, +${RISK_PENALTIES.STEEP_SLOPE}%)`);
  }

  // Visibilidade baixa
  if (weather.visibility < 3000) {
    risk += 10;
    factors.push(`🌫️ Baixa visibilidade (${(weather.visibility / 1000).toFixed(1)}km, +10%)`);
  }

  return { riskScore: Math.min(100, Math.round(risk)), riskFactors: factors };
}

// ── FILTRO DE INCIDENTES POR TRECHO ──────────────────────────────

/** Filtra incidentes próximos ao trecho (dentro de 500m da linha) */
function filterIncidentsNearLeg(
  incidents: TrafficIncident[],
  from: Coordinate,
  to: Coordinate
): TrafficIncident[] {
  return incidents.filter(inc => {
    const d = pointToSegmentDistance(
      { lat: inc.lat, lon: inc.lon }, from, to
    );
    return d < 0.5; // km
  });
}

/** Distância de um ponto a um segmento de linha (em km) */
function pointToSegmentDistance(p: Coordinate, a: Coordinate, b: Coordinate): number {
  const dx = b.lat - a.lat;
  const dy = b.lon - a.lon;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return Math.hypot(p.lat - a.lat, p.lon - a.lon) * 111;
  const t = Math.max(0, Math.min(1, ((p.lat - a.lat) * dx + (p.lon - a.lon) * dy) / lenSq));
  const projLat = a.lat + t * dx;
  const projLon = a.lon + t * dy;
  return Math.hypot(p.lat - projLat, p.lon - projLon) * 111;
}
