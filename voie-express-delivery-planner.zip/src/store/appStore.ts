// ═══════════════════════════════════════════════════════════════
// STORE GLOBAL — Estado da aplicação com React hooks
// Usa localStorage para persistência entre sessões
// Substitua por Zustand/Redux para apps maiores
// ═══════════════════════════════════════════════════════════════

import { useState, useCallback, useEffect } from 'react';
import type {
  Screen, CalculatedRoute, UserSettings, Occurrence,
  Priority, VehicleType
} from '../types';
import { DEFAULT_SETTINGS } from '../constants';

// ── Carrega configurações do localStorage ────────────────────────
function loadSettings(): UserSettings {
  try {
    const s = localStorage.getItem('voie_settings');
    return s ? { ...DEFAULT_SETTINGS, ...JSON.parse(s) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

// ── Salva configurações no localStorage ─────────────────────────
function persistSettings(settings: UserSettings) {
  localStorage.setItem('voie_settings', JSON.stringify(settings));
}

// ── Hook principal do estado global ─────────────────────────────
export function useAppStore() {
  const [screen, setScreen] = useState<Screen>('home');
  const [settings, setSettings] = useState<UserSettings>(loadSettings);
  const [currentRoute, setCurrentRoute] = useState<CalculatedRoute | null>(null);
  const [loadingProgress, setLoadingProgress] = useState({ step: 0, total: 9, message: '' });
  const [occurrences, setOccurrences] = useState<Occurrence[]>([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'warning' | 'info' } | null>(null);
  const [currentStopIndex, setCurrentStopIndex] = useState(0);

  // Monitora status de conexão
  useEffect(() => {
    const onOnline = () => { setIsOnline(true); showToast('Conexão restaurada! Sincronizando...', 'success'); };
    const onOffline = () => { setIsOnline(false); showToast('Sem conexão — modo offline ativo', 'warning'); };
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Persiste configurações ao alterar
  const updateSettings = useCallback((updates: Partial<UserSettings>) => {
    setSettings(prev => {
      const next = { ...prev, ...updates };
      persistSettings(next);
      return next;
    });
  }, []);

  // Toast temporário (auto-dismiss em 4s)
  const showToast = useCallback((message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  }, []);

  const navigate = useCallback((s: Screen) => {
    setScreen(s);
  }, []);

  return {
    screen, navigate,
    settings, updateSettings,
    currentRoute, setCurrentRoute,
    loadingProgress, setLoadingProgress,
    occurrences, setOccurrences,
    isOnline,
    toast, showToast,
    currentStopIndex, setCurrentStopIndex,
  };
}

export type AppStore = ReturnType<typeof useAppStore>;

// ── Helpers de formatação ─────────────────────────────────────────

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${Math.round(minutes)}min`;
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  return m > 0 ? `${h}h ${m}min` : `${h}h`;
}

export function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)}m`;
  return `${km.toFixed(1)}km`;
}

export function getPriorityLabel(p: Priority): string {
  const map: Record<Priority, string> = {
    fastest: 'Mais Rápido', shortest: 'Mais Curto',
    economic: 'Mais Econômico', safest: 'Mais Seguro', balanced: 'Equilibrado',
  };
  return map[p] ?? p;
}

export function getVehicleLabel(v: VehicleType): string {
  const map: Record<VehicleType, string> = {
    car: '🚗 Carro', motorcycle: '🏍️ Moto',
    truck: '🚛 Caminhão', van: '🚐 Van', boat: '⛵ Barco',
  };
  return map[v] ?? v;
}

export function getScoreColor(score: number): string {
  if (score >= 80) return '#00D4AA';
  if (score >= 50) return '#F4A261';
  return '#E63946';
}
