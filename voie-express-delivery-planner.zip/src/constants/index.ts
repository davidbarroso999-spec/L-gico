// ═══════════════════════════════════════════════════════════════
// CONSTANTES GLOBAIS — Voie Express
// ═══════════════════════════════════════════════════════════════

import type { OptimizationWeights, Priority, UserSettings } from '../types';

// ── CHAVES DE API (substituir pelos valores reais) ──────────────
export const API_KEYS = {
  ORS: 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6ImE2MGFmMzA2YmQ5NzQ4MjQ4ODljOGNhMTgzM2Y3YjAwIiwiaCI6Im11cm11cjY0In0=',
  OPENWEATHER: 'a46d5eac976d211d6bde3bbaf70073f9',
  VISUALCROSSING: 'VBC92VXW9WTHYTJMUYGSBWX78',
  TOMTOM: 'RTvaCPgTDMD4fSaOTbGkZNdHnnFs7Q4K',
};

// ── ENDPOINTS DE API ─────────────────────────────────────────────
export const API_URLS = {
  ORS_BASE: 'https://api.openrouteservice.org/v2',
  OPENWEATHER_BASE: 'https://api.openweathermap.org/data/2.5',
  VISUALCROSSING_BASE: 'https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services',
  INMET_BASE: 'https://apiprevmet3.inmet.gov.br/previsao',
  OPENTOPODATA_BASE: 'https://api.opentopodata.org/v1',
  TOMTOM_BASE: 'https://api.tomtom.com/traffic/services',
  NOMINATIM: 'https://nominatim.openstreetmap.org',
};

// ── PESOS DE OTIMIZAÇÃO POR PRIORIDADE ──────────────────────────
export const PRIORITY_WEIGHTS: Record<Priority, OptimizationWeights> = {
  fastest:   { distance: 0.2, time: 0.5, fuel: 0.2, risk: 0.1 },
  shortest:  { distance: 0.5, time: 0.3, fuel: 0.1, risk: 0.1 },
  economic:  { distance: 0.2, time: 0.2, fuel: 0.5, risk: 0.1 },
  safest:    { distance: 0.1, time: 0.1, fuel: 0.1, risk: 0.7 },
  balanced:  { distance: 0.25, time: 0.25, fuel: 0.25, risk: 0.25 },
};

// ── DADOS MOCK: 6 ENDEREÇOS EM MANAUS ───────────────────────────
export const MOCK_ADDRESSES = [
  { address: 'Av. Eduardo Ribeiro, 520 - Centro, Manaus - AM', lat: -3.1316, lon: -60.0236 },
  { address: 'Av. Djalma Batista, 1661 - Adrianópolis, Manaus - AM', lat: -3.0950, lon: -60.0089 },
  { address: 'Rua Acre, 85 - Aleixo, Manaus - AM', lat: -3.0820, lon: -59.9880 },
  { address: 'Av. Noel Nutels, 1000 - Cidade Nova, Manaus - AM', lat: -3.0450, lon: -59.9950 },
  { address: 'Rua Ferreira Pena, 200 - Flores, Manaus - AM', lat: -3.0720, lon: -60.0320 },
  { address: 'Av. General Rodrigo Otávio, 300 - Compensa, Manaus - AM', lat: -3.1150, lon: -60.0580 },
];

// ── CACHE TTL (ms) ───────────────────────────────────────────────
export const CACHE_TTL = {
  WEATHER: 30 * 60 * 1000,         // 30 minutos
  ELEVATION: 365 * 24 * 60 * 60 * 1000, // 1 ano (permanente)
  INCIDENTS: 5 * 60 * 1000,        // 5 minutos
  ROUTES: 60 * 60 * 1000,          // 1 hora
};

// ── CONFIGURAÇÕES PADRÃO ─────────────────────────────────────────
export const DEFAULT_SETTINGS: UserSettings = {
  orsKey: API_KEYS.ORS,
  openweatherKey: API_KEYS.OPENWEATHER,
  visualcrossingKey: API_KEYS.VISUALCROSSING,
  tomtomKey: API_KEYS.TOMTOM,
  defaultPriority: 'balanced',
  defaultVehicle: 'car',
  avoidDirt: false,
  avoidFlood: true,
  avoidSlopes: false,
  avoidNoSignal: false,
  preferAsphalt: true,
  darkMode: true,
  offlineMode: false,
};

// ── CONSTANTES FÍSICAS ───────────────────────────────────────────
export const FUEL_CONSUMPTION = {
  car: 10,        // km/L
  motorcycle: 25, // km/L
  truck: 5,       // km/L
  van: 8,         // km/L
  boat: 3,        // km/L (L por km)
};

// ── MAPA DE VEÍCULO PARA PERFIL ORS ─────────────────────────────
export const VEHICLE_ORS_PROFILE: Record<string, string> = {
  car: 'driving-car',
  motorcycle: 'driving-car',
  truck: 'driving-hgv',
  van: 'driving-car',
  boat: 'foot-walking', // fallback para barco
};

// ── LIMIAR DE RISCO ──────────────────────────────────────────────
export const RISK_THRESHOLD = 60; // acima disto, propõe alternativa

// ── PENALIDADES DE RISCO (percentuais) ──────────────────────────
export const RISK_PENALTIES = {
  HEAVY_RAIN: 15,        // chuva forte > 5mm/h
  THUNDERSTORM: 30,      // tempestade
  FLOOD_HISTORY: 10,     // histórico de alagamento
  TOMTOM_INCIDENT: 20,   // incidente TomTom
  STEEP_SLOPE: 10,       // ladeira íngreme
  DIRT_ROAD: 15,         // ramal sem pavimento
  NO_SIGNAL: 5,          // área sem cobertura
};

// ── CORES DO DESIGN SYSTEM ───────────────────────────────────────
export const COLORS = {
  PRIMARY: '#0B3D2E',
  ACCENT: '#D4A017',
  TECH: '#00D4AA',
  ALERT: '#E63946',
  WARNING: '#F4A261',
  BG_DARK: '#0F172A',
  CARD_DARK: '#1E293B',
  TEXT_LIGHT: '#F1F5F9',
};

// ── LOADING MESSAGES ─────────────────────────────────────────────
export const LOADING_MESSAGES = [
  'Geocodificando endereços...',
  'Calculando matriz de distâncias...',
  'Analisando condições climáticas...',
  'Verificando elevação e relevo...',
  'Consultando incidentes de trânsito...',
  'Aplicando perfil sazonal...',
  'Otimizando sequência de entregas...',
  'Calculando score de risco por trecho...',
  'Preparando visualização da rota...',
];
